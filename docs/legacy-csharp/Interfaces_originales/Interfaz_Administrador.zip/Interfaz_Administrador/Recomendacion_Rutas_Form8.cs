﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaz_Administrador
{
    public partial class Recomendacion_Rutas_Form8 : Form
    {
        public Recomendacion_Rutas_Form8()
        {
            InitializeComponent();
        }
    }
}

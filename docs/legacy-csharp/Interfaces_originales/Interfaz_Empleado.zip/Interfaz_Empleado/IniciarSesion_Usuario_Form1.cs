﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaz_Empleado
{
    public partial class IniciarSesion_Usuario_Form1 : Form
    {
        public IniciarSesion_Usuario_Form1()
        {
            InitializeComponent();
        }
    }
}

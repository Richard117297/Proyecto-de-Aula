﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaz_Usuario
{
    public partial class DigitarInfo_Boleto_Form5 : Form
    {
        public DigitarInfo_Boleto_Form5()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void DigitarInfo_Boleto_Form5_Load(object sender, EventArgs e)
        {

        }
    }
}

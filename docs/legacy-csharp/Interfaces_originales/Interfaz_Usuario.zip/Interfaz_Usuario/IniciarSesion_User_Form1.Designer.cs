﻿namespace Interfaz_Usuario
{
    partial class IniciarSesion_User_Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIngresar = new System.Windows.Forms.Button();
            this.textBox2_txtContraseña = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1_txtUsuario = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Iniciar = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIngresar
            // 
            this.btnIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresar.Location = new System.Drawing.Point(514, 684);
            this.btnIngresar.Name = "btnIngresar";
            this.btnIngresar.Size = new System.Drawing.Size(342, 102);
            this.btnIngresar.TabIndex = 11;
            this.btnIngresar.Text = "Ingresar";
            this.btnIngresar.UseVisualStyleBackColor = true;
            this.btnIngresar.Click += new System.EventHandler(this.Ingresar_Click);
            // 
            // textBox2_txtContraseña
            // 
            this.textBox2_txtContraseña.Location = new System.Drawing.Point(318, 552);
            this.textBox2_txtContraseña.Multiline = true;
            this.textBox2_txtContraseña.Name = "textBox2_txtContraseña";
            this.textBox2_txtContraseña.Size = new System.Drawing.Size(740, 52);
            this.textBox2_txtContraseña.TabIndex = 10;
            this.textBox2_txtContraseña.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(309, 464);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(245, 51);
            this.label2.TabIndex = 9;
            this.label2.Text = "Contraseña";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox1_txtUsuario
            // 
            this.textBox1_txtUsuario.Location = new System.Drawing.Point(318, 353);
            this.textBox1_txtUsuario.Multiline = true;
            this.textBox1_txtUsuario.Name = "textBox1_txtUsuario";
            this.textBox1_txtUsuario.Size = new System.Drawing.Size(725, 51);
            this.textBox1_txtUsuario.TabIndex = 8;
            this.textBox1_txtUsuario.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(309, 264);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 51);
            this.label1.TabIndex = 7;
            this.label1.Text = "Usuario";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Iniciar
            // 
            this.Iniciar.AutoSize = true;
            this.Iniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Iniciar.Location = new System.Drawing.Point(434, 114);
            this.Iniciar.Name = "Iniciar";
            this.Iniciar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Iniciar.Size = new System.Drawing.Size(504, 85);
            this.Iniciar.TabIndex = 6;
            this.Iniciar.Text = "Iniciar Sesión\r\n";
            this.Iniciar.Click += new System.EventHandler(this.Iniciar_Click);
            // 
            // IniciarSesion_User_Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 900);
            this.Controls.Add(this.btnIngresar);
            this.Controls.Add(this.textBox2_txtContraseña);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1_txtUsuario);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Iniciar);
            this.Name = "IniciarSesion_User_Form1";
            this.Text = "IniciarSesion_User_Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIngresar;
        private System.Windows.Forms.TextBox textBox2_txtContraseña;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1_txtUsuario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Iniciar;
    }
}
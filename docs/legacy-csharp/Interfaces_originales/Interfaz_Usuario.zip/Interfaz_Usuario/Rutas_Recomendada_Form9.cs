﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaz_Usuario
{
    public partial class Rutas_Recomendada_Form9 : Form
    {
        public Rutas_Recomendada_Form9()
        {
            InitializeComponent();
        }

        private void Rutas_Recomendada_Form9_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;

namespace ProyectoFinal.Base_de_datos_JSON
{
    public static class JsonHelper
    {
        public static void GuardarDatos<T>(string rutaArchivo, List<T> datos)
        {
            try
            {
                string directorio = Path.GetDirectoryName(rutaArchivo);
                if (!string.IsNullOrEmpty(directorio) && !Directory.Exists(directorio))
                {
                    Directory.CreateDirectory(directorio);
                }

                string json = JsonSerializer.Serialize(datos, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(rutaArchivo, json);
                Console.WriteLine($"Datos guardados exitosamente en {rutaArchivo}.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al guardar los datos en {rutaArchivo}: {ex.Message}");
            }
        }

        public static List<T> CargarDatos<T>(string rutaArchivo)
        {
            try
            {
                if (!File.Exists(rutaArchivo))
                {
                    Console.WriteLine($"El archivo {rutaArchivo} no existe. Se creará un archivo vacío.");
                    File.WriteAllText(rutaArchivo, "[]");
                    return new List<T>();
                }

                string json = File.ReadAllText(rutaArchivo);
                return JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();
            }
            catch (JsonException ex)
            {
                Console.WriteLine($"Error al cargar los datos de {rutaArchivo}: El archivo tiene un formato incorrecto. {ex.Message}");
                return new List<T>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al cargar los datos de {rutaArchivo}: {ex.Message}");
                return new List<T>();
            }
        }



    }
}

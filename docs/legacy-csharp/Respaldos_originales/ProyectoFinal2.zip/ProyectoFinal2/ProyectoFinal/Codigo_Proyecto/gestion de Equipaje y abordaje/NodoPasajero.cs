﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Codigo_ProyectoAula;

namespace ProyectoFinal.Codigo_Proyecto.gestion_de_equipaje_y_abordaje
{
    public class NodoPasajero
    {
        private Pasajero pasajero;
        private NodoPasajero siguiente;

        public Pasajero Pasajero { get => pasajero; set => pasajero = value; }
        public NodoPasajero Siguiente { get => siguiente; set => siguiente = value; }


        public NodoPasajero(Pasajero pasajero)
        {
            Pasajero = pasajero;
            Siguiente = null;
        }
    }
}

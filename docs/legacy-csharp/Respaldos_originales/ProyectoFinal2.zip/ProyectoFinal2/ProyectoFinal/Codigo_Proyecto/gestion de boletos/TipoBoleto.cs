﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Codigo_ProyectoAula
{

    public enum TipoBoletoEnum
    {
        Premium, Ejecutivo, Estandar, Desconocido
    }

    public class TipoBoleto {

        private bool prioridadEmbarque;
        private TipoBoletoEnum tipo;

        public bool PrioridadEmbarque { get => prioridadEmbarque; set => prioridadEmbarque = value; }
        public TipoBoletoEnum Tipo { get => tipo; set => tipo = value; }

        
        public TipoBoleto() {

            Tipo = tipo;
            PrioridadEmbarque = prioridadEmbarque;
        }


        public TipoBoletoEnum SeleccionarTipoBoleto(string tipoBoleto) { 

            switch (tipoBoleto.ToLower()) 
            {
                case "premium":
                    return TipoBoletoEnum.Premium;

                case "ejecutivo":
                    return TipoBoletoEnum.Ejecutivo;

                case "estandar":
                    return TipoBoletoEnum.Estandar;

                default:
                    throw new ArgumentException("Tipo de boleto no válido.");
            }
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.Codigo_Proyecto.gestion_de_rutas
{
    public class Arista {

        private int destino;
        private int distancia;
        

        public int Destino { get => destino; set => destino = value; }
        public int Distancia { get => distancia; set => distancia = value; }
        

        public Arista(int destino, int distancia) {

            Destino = destino;
            Distancia = distancia;
            
        }

        public string toString() {

            return "Arista [Destino: " + destino + ", Distancia: " + distancia + " km]";
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Codigo_ProyectoAula
{
    public class NodoVagon {

        private Vagon vagon;
        private NodoVagon siguiente;

        public Vagon Vagon { get => vagon; set => vagon = value; }
        public NodoVagon Siguiente { get => siguiente; set => siguiente = value; }

        public NodoVagon(Vagon vagon)
        {
            Vagon = vagon;
            Siguiente = null;
        }

    }
}

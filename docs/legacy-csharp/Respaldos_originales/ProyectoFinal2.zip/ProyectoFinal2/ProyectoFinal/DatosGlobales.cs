﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Codigo_ProyectoAula;
using ProyectoFinal.Codigo_Proyecto.gestion_de_equipaje_y_abordaje;
using System.IO;
using System.Text.Json;



namespace ProyectoFinal
{
    public static class DatosGlobales
    {
        public static ListaEnlazadaSimple_Boletos ListaGlobalDeBoletos { get; private set; }

        public static ListaEnlazadaSimple_Rutas ListaGlobalDeRutasRecomendadas { get; private set; }

        public static ListaEnlazadaSimple_Trenes ListaGlobalDeTrenes { get; private set; }

        public static ListaEnlazadaSimple_Pasajeros ListaGlobalDePasajeros { get; private set; }

        public static Dictionary<string, double> PreciosRutaPorKilometro { get; private set; }

        public static Pila_Vagon ListaGlobalDeVagones { get; private set; }

        public static Pila_Equipaje ListaGlobalDeEquipajes { get; set; } = new Pila_Equipaje();

        public static List<Boleto> GetAllBoletos()
        {
            return ListaGlobalDeBoletos?.GetAllBoletos() ?? new List<Boleto>();
        }

        public static List<Ruta> GetAllRutas()
        {
            return ListaGlobalDeRutasRecomendadas?.GetAllRutas() ?? new List<Ruta>();
        }

        public static List<Tren> GetAllTrenes()
        {
            return ListaGlobalDeTrenes?.GetAllTrenes() ?? new List<Tren>();
        }

        public static List<Vagon> GetAllVagones()
        {
            return ListaGlobalDeVagones?.GetAllVagones() ?? new List<Vagon>();
        }

        public static void InicializarDatos()
        {

            ListaGlobalDeBoletos = new ListaEnlazadaSimple_Boletos();

            ListaGlobalDeRutasRecomendadas = new ListaEnlazadaSimple_Rutas();

            ListaGlobalDeTrenes = new ListaEnlazadaSimple_Trenes();

            ListaGlobalDePasajeros = new ListaEnlazadaSimple_Pasajeros();

            PreciosRutaPorKilometro = new Dictionary<string, double>();

            ListaGlobalDeVagones = new Pila_Vagon();

            ListaGlobalDeEquipajes = new Pila_Equipaje();


            string rutaArchivoBoletos = @"Base de datos JSON\Boleto.json";
            List<Boleto> boletosCargados = Boleto.CargarDatos(rutaArchivoBoletos);

            if (boletosCargados != null && boletosCargados.Count > 0)
            {
                foreach (var boleto in boletosCargados)
                {
                    ListaGlobalDeBoletos.AddBoleto(boleto);
                }
            }

            string rutaArchivoTrenes = @"Base de datos JSON\Tren.json";
            List<Tren> trenesCargados = Tren.CargarDatos(rutaArchivoTrenes);

            if (trenesCargados != null && trenesCargados.Count > 0)
            {
                foreach (var tren in trenesCargados)
                {
                    ListaGlobalDeTrenes.agregarTren(tren);
                }
            }

            string rutaArchivoRutas = @"Base de datos JSON\Ruta.json";
            List<Ruta> rutasCargadas = Ruta.CargarDatos(rutaArchivoRutas);

            if (rutasCargadas != null && rutasCargadas.Count > 0)
            {
                foreach (var ruta in rutasCargadas)
                {
                    ListaGlobalDeRutasRecomendadas.addRuta(ruta);
                }
            }

            string rutaArchivoVagones = @"Base de datos JSON\Vagon.json";
            List<Vagon> vagonesCargados = Vagon.CargarDatos(rutaArchivoVagones);

            if (vagonesCargados != null && vagonesCargados.Count > 0)
            {
                foreach (var vagon in vagonesCargados)
                {
                    ListaGlobalDeVagones.push(vagon);
                }
            }

            string rutaArchivoEquipaje = @"Base de datos JSON\Equipaje.json";

            string[] nombresEstaciones = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K" };

            int?[,] distancias = {

                {null, 30, 40, 50, 50, null, null, null, null, null, null },

                {30, null, null, null, null, null, null, 80, 120, 110, null },

                {40, null, null, null, null, null, null, null, null, null, null },

                {50, null, null, null, null, null, 20, null, null, null, null },

                {50, null, null, null, null, 20, null, 65, null, null, null },

                {null, null, null, null, 20, null, 65, null, null, null, null },

                {null, null, null, 20, null, 65, null, 80, null, null, null },

                {null, 80, null, null, null, null, 80, null, 30, 145, null },

                {null, 120, null, null, null, null, null, 30, null, null, null },

                {null, 110, null, null, null, null, null, 145, null, null, null },

                {null, null, null, null, null, null, null, null, null, null, null }

            };



            GrafoEstacion grafoInicial = new GrafoEstacion(nombresEstaciones.Length);



            for (int i = 0; i < nombresEstaciones.Length; i++)

            {

                grafoInicial.AddEstacion(new Estacion(new string[] { nombresEstaciones[i] }));

            }



            for (int i = 0; i < nombresEstaciones.Length; i++)

            {

                for (int j = 0; j < nombresEstaciones.Length; j++)

                {

                    if (distancias[i, j].HasValue)

                    {

                        grafoInicial.AddRutaNoDirigida(i, j, distancias[i, j].Value);



                        string claveRuta = $"{nombresEstaciones[i]}-{nombresEstaciones[j]}";

                        if (!PreciosRutaPorKilometro.ContainsKey(claveRuta))

                        {



                            PreciosRutaPorKilometro.Add(claveRuta, 5.0);



                            string claveRutaInversa = $"{nombresEstaciones[j]}-{nombresEstaciones[i]}";

                            if (!PreciosRutaPorKilometro.ContainsKey(claveRutaInversa))

                            {

                                PreciosRutaPorKilometro.Add(claveRutaInversa, 5.0);

                            }

                        }

                    }

                }

            }

            ListaGlobalDeBoletos.Valor = grafoInicial;

        }

        public static void GuardarDatosGlobales(string rutaArchivo)
        {
            var datos = new
            {
                ListaGlobalDeBoletos = "boletos.json",
                ListaGlobalDeRutas = "rutas.json",
                ListaGlobalDeEstaciones = "estaciones.json",
                ListaGlobalDeTrenes = "trenes.json",
                ListaGlobalDeRutasRecomendadas = "rutas_recomendadas.json"
            };

        } 

    private static void GuardarDatos<T>(string rutaArchivo, List<T> datos)
    {
        string json = JsonSerializer.Serialize(datos, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(rutaArchivo, json);
    }

    private static List<T> CargarDatos<T>(string rutaArchivo)
    {
        if (!File.Exists(rutaArchivo)) return new List<T>();
        string json = File.ReadAllText(rutaArchivo);
        return JsonSerializer.Deserialize<List<T>>(json) ?? new List<T>();
    }


    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using Interfaz_Administrador;
using Interfaz_Empleado;
using Interfaz_Usuario;

namespace ProyectoFinal
{
    public partial class Form1 : Form
    {
        

        public Form1()
        {
            InitializeComponent();

        }

        private void Iniciar_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            IniciarSesion_User_Form1 iniciarSesionUsuario = new IniciarSesion_User_Form1();
            iniciarSesionUsuario.Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            IniciarSesion_Empleado_Form1 iniciarSesionEmpleado = new IniciarSesion_Empleado_Form1();
            iniciarSesionEmpleado.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (DatosGlobales.ListaGlobalDeBoletos == null)
            {
                MessageBox.Show("Error fatal: Los datos globales del sistema no están inicializados.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit(); 
                return;
            }


            IniciarSesion_Admin_Form1 iniciarSesionAdmin = new IniciarSesion_Admin_Form1();
            iniciarSesionAdmin.Show();
            this.Hide();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

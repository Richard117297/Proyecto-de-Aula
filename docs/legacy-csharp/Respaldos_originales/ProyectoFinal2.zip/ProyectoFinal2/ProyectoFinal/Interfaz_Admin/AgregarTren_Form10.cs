﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class AgregarTren_Form10 : Form
    {
        private const int ASIENTOS_PASAJEROS_POR_VAGON = 34;
        private string rutaArchivoTrenes = @"Base de datos JSON\Tren.json"; 

        public AgregarTren_Form10()
        {
            InitializeComponent();
        }

        private void AgregarTren_Form10_Load(object sender, EventArgs e)
        {

            textBox3.Enabled = false; 
            textBox4.Enabled = false; 
            textBox1.Enabled = false; 
            textBox5.Enabled = false; 
            textBox6.Enabled = false; 
            textBox8.Enabled = false; 
            comboBox1.Enabled = false; 
            button1.Enabled = false; 


            textBox2.Text = ""; 
            textBox3.Text = "";
            textBox4.Text = "";
            textBox1.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox8.Text = "";
            comboBox1.Items.Clear(); 


            button2.Enabled = true; 
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            LimpiarCamposResultado();
            button1.Enabled = false;
        }


        private void LimpiarCamposResultado()
        {
            textBox3.Text = ""; 
            textBox4.Text = ""; 
            textBox1.Text = ""; 
            textBox5.Text = ""; 
            textBox6.Text = ""; 
            textBox8.Text = ""; 
            comboBox1.Items.Clear(); 
            comboBox1.Enabled = false; 
            button1.Enabled = false; 
        }



        private void button2_Click(object sender, EventArgs e) 
        {
            string tipoTrenTexto = textBox2.Text.Trim();
            if (string.IsNullOrEmpty(tipoTrenTexto))
            {
                MessageBox.Show("Por favor, ingrese el tipo de tren (Arnold o Mercedes-Benz).", "Tipo de Tren Requerido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                LimpiarCamposResultado();
                return;
            }


            Tren trenTemporal = new Tren();
            int capacidadTotalVagones = 0;
            try
            {
                trenTemporal.AsignarTipoTren(tipoTrenTexto);
                capacidadTotalVagones = trenTemporal.CapacidadVagones; 
                textBox3.Text = capacidadTotalVagones.ToString(); 
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Tipo de Tren Inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                LimpiarCamposResultado();
                return;
            }


            int cantidadVagonesCargaCalculada = 0;
            int cantidadVagonesPasajerosCalculada = 0;


            if (tipoTrenTexto.Equals("arnold", StringComparison.OrdinalIgnoreCase))
            {
                cantidadVagonesCargaCalculada = 8;
                cantidadVagonesPasajerosCalculada = 24;
            }
            else if (tipoTrenTexto.Equals("mercedes-benz", StringComparison.OrdinalIgnoreCase) || tipoTrenTexto.Equals("mercedez-benz", StringComparison.OrdinalIgnoreCase))
            {
                cantidadVagonesCargaCalculada = 7;
                cantidadVagonesPasajerosCalculada = 21;
            }

            int totalVagonesCalculados = cantidadVagonesCargaCalculada + cantidadVagonesPasajerosCalculada;
            if (totalVagonesCalculados > capacidadTotalVagones)
            {
                int diff = totalVagonesCalculados - capacidadTotalVagones;
                cantidadVagonesPasajerosCalculada -= diff;
                if (cantidadVagonesPasajerosCalculada < 0) cantidadVagonesPasajerosCalculada = 0;
            }

            int cantidadPasajerosTotalCalculada = cantidadVagonesPasajerosCalculada * ASIENTOS_PASAJEROS_POR_VAGON;


            textBox5.Text = cantidadVagonesCargaCalculada.ToString();
            textBox6.Text = cantidadVagonesPasajerosCalculada.ToString(); 
            textBox8.Text = cantidadPasajerosTotalCalculada.ToString(); 


            comboBox1.Items.Clear();
            comboBox1.Enabled = false;

            if (DatosGlobales.ListaGlobalDeRutasRecomendadas != null)
            {
                List<Ruta> rutasPublicadas = DatosGlobales.ListaGlobalDeRutasRecomendadas.GetAllRutas();

                if (rutasPublicadas != null && rutasPublicadas.Count > 0)
                {
                    foreach (Ruta ruta in rutasPublicadas)
                    {
                        comboBox1.Items.Add(ruta); 
                    }
                    comboBox1.Enabled = true;
                    if (comboBox1.Items.Count > 0)
                    {
                        comboBox1.SelectedIndex = 0;
                    }
                }
                else
                {
                    MessageBox.Show("No hay rutas publicadas disponibles para asignar a un tren. Por favor, cree rutas primero.", "Rutas No Disponibles", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Error interno: La lista de rutas publicadas no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            string idTrenGenerado = Guid.NewGuid().ToString("N").Substring(0, 10).ToUpper();
            textBox4.Text = idTrenGenerado;

            textBox1.Text = "0.0";

            button1.Enabled = (comboBox1.SelectedItem != null);

            MessageBox.Show("Datos del tren calculados. Por favor, seleccione una ruta (si hay disponibles) y haga clic en 'Agregar Tren'.", "Actualización Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (comboBox1.SelectedItem is Ruta rutaSeleccionada &&
                !string.IsNullOrEmpty(textBox2.Text) &&
                !string.IsNullOrEmpty(textBox3.Text) &&
                !string.IsNullOrEmpty(textBox4.Text) &&
                !string.IsNullOrEmpty(textBox1.Text) &&
                !string.IsNullOrEmpty(textBox5.Text) &&
                !string.IsNullOrEmpty(textBox6.Text) &&
                !string.IsNullOrEmpty(textBox8.Text)
               )
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }



        private void button1_Click(object sender, EventArgs e) 
        {
            if (string.IsNullOrEmpty(textBox2.Text) ||
                string.IsNullOrEmpty(textBox3.Text) ||
                string.IsNullOrEmpty(textBox4.Text) ||
                string.IsNullOrEmpty(textBox1.Text) ||
                string.IsNullOrEmpty(textBox5.Text) ||
                string.IsNullOrEmpty(textBox6.Text) ||
                string.IsNullOrEmpty(textBox8.Text) ||
                comboBox1.SelectedItem == null || !(comboBox1.SelectedItem is Ruta rutaAsignadaSeleccionada)
               )
            {
                MessageBox.Show("Por favor, complete toda la información y seleccione una ruta válida antes de agregar el tren.", "Información Incompleta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string tipoTren = textBox2.Text.Trim();
            string idTren = textBox4.Text.Trim();

            if (!int.TryParse(textBox3.Text, out int capacidadTotalVagones) ||
                !double.TryParse(textBox1.Text, out double kilometraje) ||
                !int.TryParse(textBox5.Text, out int vagonesCarga) ||
                !int.TryParse(textBox6.Text, out int vagonesPasajeros) ||
                !int.TryParse(textBox8.Text, out int cantidadPasajerosTotal)
               )
            {
                MessageBox.Show("Error al obtener valores numéricos.", "Error de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (DatosGlobales.ListaGlobalDeTrenes == null)
            {
                MessageBox.Show("Error interno: La lista global de trenes no está inicializada.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (DatosGlobales.ListaGlobalDeTrenes.BuscarTrenPorId(idTren) != null)
            {
                MessageBox.Show($"Ya existe un tren con el ID {idTren}.", "ID Duplicado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Tren nuevoTren = new Tren(
                idTren,
                tipoTren,
                kilometraje,
                rutaAsignadaSeleccionada,
                capacidadTotalVagones,
                vagonesCarga,
                vagonesPasajeros,
                cantidadPasajerosTotal 
            );


            DatosGlobales.ListaGlobalDeTrenes.agregarTren(nuevoTren);

            List<Tren> trenesAGuardar = DatosGlobales.ListaGlobalDeTrenes.GetAllTrenes();
            Tren.GuardarDatos(rutaArchivoTrenes, trenesAGuardar);

            MessageBox.Show($"Tren '{nuevoTren.IdTren}' (Tipo: {nuevoTren.TipoTren}) agregado exitosamente al sistema.", "Tren Agregado", MessageBoxButtons.OK, MessageBoxIcon.Information);


            LimpiarCamposResultado();
            textBox2.Clear();
            button1.Enabled = false;
            button2.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e) 
        {
            GestionTrenes_Form9 gestionTrenesForm = new GestionTrenes_Form9();
            gestionTrenesForm.Show();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void textBox8_TextChanged(object sender, EventArgs e) { }
        private void textBox7_TextChanged(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using Interfaz_Administrador;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProyectoFinal.Interfaz_Admin
{
    public partial class AgregarVagonAlTren_Form10_5 : Form
    {
        private Tren trenSeleccionadoAdmin;
        private Random random;
        private string rutaArchivoTrenes = @"Base de datos JSON\Tren.json";

        public AgregarVagonAlTren_Form10_5()
        {
            InitializeComponent();
            this.random = new Random();
        }

        private void AgregarVagonAlTren_Form10_5_Load(object sender, EventArgs e)
        {
            CargarTrenesDisponibles();
            DeshabilitarCamposVagon();
        }

        private void CargarTrenesDisponibles()
        {
            comboBox2.Items.Clear();
            comboBox2.SelectedIndex = -1;
            trenSeleccionadoAdmin = null;
            LimpiarCamposTren();
            DeshabilitarCamposVagon();

            if (DatosGlobales.ListaGlobalDeTrenes == null || DatosGlobales.ListaGlobalDeTrenes.Cabeza == null)
            {
                MessageBox.Show("No hay trenes disponibles para agregar vagones.", "Sin Trenes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox2.Enabled = false;
                return;
            }

            List<Tren> todosLosTrenes = DatosGlobales.ListaGlobalDeTrenes.GetAllTrenes();

            if (todosLosTrenes.Count > 0)
            {
                foreach (Tren tren in todosLosTrenes)
                {
                    comboBox2.Items.Add(tren.IdTren);
                }
                comboBox2.Enabled = true;
            }
            else
            {
                MessageBox.Show("No hay trenes disponibles para agregar vagones.", "Sin Trenes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox2.Enabled = false;
            }
        }

        private void LimpiarCamposTren()
        {
            textBox4.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox8.Clear();
            textBox5.Clear();
            textBox6.Clear();
            LimpiarCamposVagon();
        }

        private void LimpiarCamposVagon()
        {
            textBox1.Clear();
            textBox7.Clear();
            DeshabilitarCamposVagon();
        }

        private void DeshabilitarCamposVagon()
        {
            textBox1.Enabled = false;
            textBox7.Enabled = false;
            button1.Enabled = false;
        }

        private void HabilitarCamposVagon(bool esPasajero)
        {
            if (esPasajero)
            {
                textBox1.Enabled = true;
                textBox7.Enabled = false;
                textBox7.Clear();
            }
            else
            {
                textBox1.Enabled = false;
                textBox1.Clear();
                textBox7.Enabled = true;
            }
            button1.Enabled = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string idTrenSeleccionado = comboBox2.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(idTrenSeleccionado))
            {
                trenSeleccionadoAdmin = DatosGlobales.ListaGlobalDeTrenes.BuscarTrenPorId(idTrenSeleccionado);

                if (trenSeleccionadoAdmin != null)
                {
                    MostrarInformacionTren(trenSeleccionadoAdmin);
                }
                else
                {
                    LimpiarCamposTren();
                    DeshabilitarCamposVagon();
                    MessageBox.Show($"No se encontró el tren con ID '{idTrenSeleccionado}'.", "Error de Búsqueda", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                trenSeleccionadoAdmin = null;
                LimpiarCamposTren();
                DeshabilitarCamposVagon();
            }
        }

        private void MostrarInformacionTren(Tren tren)
        {
            if (tren != null)
            {
                textBox4.Text = tren.IdTren;
                textBox2.Text = tren.RutaAsignada != null ? $"{tren.RutaAsignada.EstacionDePartida?.NombreEstacion[0] ?? "N/A"} a {tren.RutaAsignada.EstacionDeLlegada?.NombreEstacion[0] ?? "N/A"}" : "Sin Ruta";
                textBox3.Text = tren.CapacidadVagones.ToString();
                textBox8.Text = tren.CantidadPasajerosTotal.ToString();

                textBox5.Text = tren.CantidadVagonesCarga.ToString();
                textBox6.Text = tren.CantidadVagonesPasajeros.ToString();

                EvaluarTipoVagonAAgregar();
            }
        }

        private void EvaluarTipoVagonAAgregar()
        {
            if (trenSeleccionadoAdmin == null)
            {
                DeshabilitarCamposVagon();
                return;
            }

            int vagonesActualesPasajeros = trenSeleccionadoAdmin.PilaVagones.GetAllVagones().Count(v => v.TipoVagon == "Pasajeros");
            int vagonesActualesCarga = trenSeleccionadoAdmin.PilaVagones.GetAllVagones().Count(v => v.TipoVagon == "Carga");

            int vagonesEsperadosPasajeros = trenSeleccionadoAdmin.CantidadVagonesPasajeros;
            int vagonesEsperadosCarga = trenSeleccionadoAdmin.CantidadVagonesCarga;

            LimpiarCamposVagon();

            bool puedeAgregarPasajero = vagonesActualesPasajeros < vagonesEsperadosPasajeros;
            bool puedeAgregarCarga = vagonesActualesCarga < vagonesEsperadosCarga;

            if (puedeAgregarPasajero && puedeAgregarCarga)
            {
                HabilitarCamposVagon(true); 
                MessageBox.Show($"Puede agregar vagones de pasajeros ({vagonesEsperadosPasajeros - vagonesActualesPasajeros} restantes) o de carga ({vagonesEsperadosCarga - vagonesActualesCarga} restantes). Ingrese nombre de vagón de pasajeros.", "Seleccione Tipo de Vagón");
            }
            else if (puedeAgregarPasajero)
            {
                HabilitarCamposVagon(true);
                MessageBox.Show($"Puede agregar {vagonesEsperadosPasajeros - vagonesActualesPasajeros} vagones de pasajeros más. Ingrese nombre de vagón de pasajeros.", "Agregar Vagón Pasajero");
            }
            else if (puedeAgregarCarga)
            {
                HabilitarCamposVagon(false);
                MessageBox.Show($"Puede agregar {vagonesEsperadosCarga - vagonesActualesCarga} vagones de carga más. Ingrese nombre de vagón de carga.", "Agregar Vagón Carga");
            }
            else
            {
                DeshabilitarCamposVagon();
                MessageBox.Show("Se ha alcanzado la cantidad máxima de vagones para este tren.", "Límite de Vagones Alcanzado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem != null)
            {
                string idTrenSeleccionado = comboBox2.SelectedItem.ToString();
                trenSeleccionadoAdmin = DatosGlobales.ListaGlobalDeTrenes.BuscarTrenPorId(idTrenSeleccionado);

                if (trenSeleccionadoAdmin != null)
                {
                    MostrarInformacionTren(trenSeleccionadoAdmin);
                }
                else
                {
                    LimpiarCamposTren();
                    DeshabilitarCamposVagon();
                    MessageBox.Show($"No se encontró el tren con ID '{idTrenSeleccionado}'.", "Error de Búsqueda", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Por favor, seleccione un tren primero.", "Tren No Seleccionado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                LimpiarCamposTren();
                DeshabilitarCamposVagon();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (trenSeleccionadoAdmin == null)
        {
            MessageBox.Show("Por favor, seleccione un tren antes de agregar un vagón.", "Tren No Seleccionado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        
        string nombreVagonPasajero = textBox1.Text.Trim();
        string nombreVagonCarga = textBox7.Text.Trim();

        
        bool agregandoPasajero = textBox1.Enabled && !string.IsNullOrEmpty(nombreVagonPasajero);
        bool agregandoCarga = textBox7.Enabled && !string.IsNullOrEmpty(nombreVagonCarga);

        
        if (!agregandoPasajero && !agregandoCarga)
        {
            MessageBox.Show("Por favor, ingrese el nombre del vagón en el campo habilitado.", "Nombre del Vagón Vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        string nombreVagon = agregandoPasajero ? nombreVagonPasajero : nombreVagonCarga;

        if (trenSeleccionadoAdmin.PilaVagones.GetAllVagones().Any(v => v.IdDelVagon != null && v.IdDelVagon.Equals(nombreVagon, StringComparison.OrdinalIgnoreCase)))
        {
            MessageBox.Show($"Ya existe un vagón con el nombre '{nombreVagon}' en este tren. Por favor, use un nombre diferente.", "Nombre de Vagón Duplicado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }


        Vagon nuevoVagon = new Vagon(); 
        nuevoVagon.IdDelVagon = nombreVagon;

        if (agregandoPasajero)
        {
            nuevoVagon.TipoVagon = "Pasajeros";
            int tipoAleatorio = random.Next(3);
            switch (tipoAleatorio)
            {
                case 0: nuevoVagon.TipoBoleto = TipoBoletoEnum.Premium; nuevoVagon.CapacidadDePasajeros = 4; break;
                case 1: nuevoVagon.TipoBoleto = TipoBoletoEnum.Ejecutivo; nuevoVagon.CapacidadDePasajeros = 8; break;
                case 2: nuevoVagon.TipoBoleto = TipoBoletoEnum.Estandar; nuevoVagon.CapacidadDePasajeros = 22; break;
                default: nuevoVagon.TipoBoleto = TipoBoletoEnum.Estandar; nuevoVagon.CapacidadDePasajeros = 22; break;
            }
             nuevoVagon.CapacidadDeEquipajeKg = random.Next(100, 301);
             nuevoVagon.PesoLimKg = random.Next(5000, 10001); 



            if (trenSeleccionadoAdmin.PilaVagones.GetAllVagones().Count(v => v.TipoVagon == "Pasajeros") >= trenSeleccionadoAdmin.CantidadVagonesPasajeros)
            {
                MessageBox.Show("Se ha alcanzado la cantidad máxima de vagones de pasajeros para este tren.", "Límite Alcanzado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DeshabilitarCamposVagon(); 
                return;
            }
        }
        else if (agregandoCarga)
        {
            nuevoVagon.TipoVagon = "Carga";
            nuevoVagon.TipoBoleto = TipoBoletoEnum.Desconocido; 

            nuevoVagon.CapacidadDePasajeros = 0; 
            nuevoVagon.CapacidadDeEquipajeKg = random.Next(5000, 15001); 
            nuevoVagon.PesoLimKg = random.Next(10000, 30001); 



            if (trenSeleccionadoAdmin.PilaVagones.GetAllVagones().Count(v => v.TipoVagon == "Carga") >= trenSeleccionadoAdmin.CantidadVagonesCarga)
            {
                MessageBox.Show("Se ha alcanzado la cantidad máxima de vagones de carga para este tren.", "Límite Alcanzado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DeshabilitarCamposVagon();
                return;
            }
        }

        trenSeleccionadoAdmin.PilaVagones.AddVagon(nuevoVagon);

        try
        {
            List<Tren> todosLosTrenes = DatosGlobales.ListaGlobalDeTrenes.GetAllTrenes();
            Tren.GuardarDatos(rutaArchivoTrenes, todosLosTrenes);

            MessageBox.Show($"Vagón '{nuevoVagon.IdDelVagon}' ({nuevoVagon.TipoVagon}, Tipo Boleto: {nuevoVagon.TipoBoleto}) agregado exitosamente al tren '{trenSeleccionadoAdmin.IdTren}' y los cambios guardados.", "Vagón Agregado", MessageBoxButtons.OK, MessageBoxIcon.Information);

            textBox1.Clear();
            textBox7.Clear();


            EvaluarTipoVagonAAgregar();

        }
        catch (Exception ex)
        {
             MessageBox.Show($"Ocurrió un error al guardar los datos después de agregar el vagón: {ex.Message}", "Error al Guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            GestionTrenes_Form9 gestionTrenesForm = new GestionTrenes_Form9();
            gestionTrenesForm.Show();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void label9_Click(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { }
        private void label10_Click(object sender, EventArgs e) { }
        private void textBox8_TextChanged(object sender, EventArgs e) { }
        private void label11_Click(object sender, EventArgs e) { }
        private void textBox7_TextChanged(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
    }
}

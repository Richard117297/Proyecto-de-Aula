﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class AlmacenamientoDeTrenes_Form12 : Form
    {
        public AlmacenamientoDeTrenes_Form12()
        {
            InitializeComponent();
        }

        private void AlmacenamientoDeTrenes_Form12_Load(object sender, EventArgs e)
        {

            CargarTrenesEnDesplegable();

            richTextBox1.Enabled = false; 
            richTextBox1.Text = ""; 
            button2.Enabled = false; 

            comboBox1.Enabled = (comboBox1.Items.Count > 0);


        }


        private void CargarTrenesEnDesplegable()
        {
            comboBox1.Items.Clear();


            if (DatosGlobales.ListaGlobalDeTrenes != null && !DatosGlobales.ListaGlobalDeTrenes.EstaVacia()) 
            {

                List<Tren> listaTrenes = DatosGlobales.ListaGlobalDeTrenes.GetAllTrenes(); 

                if (listaTrenes != null && listaTrenes.Count > 0)
                {

                    foreach (Tren tren in listaTrenes)
                    {

                        comboBox1.Items.Add(tren);
                    }

                    comboBox1.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay trenes agregados al sistema.", "Lista Vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    comboBox1.Enabled = false;
                }
            }
            else
            {

                MessageBox.Show("No hay trenes agregados al sistema.", "Lista Vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox1.Enabled = false;
            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            richTextBox1.Text = "";
            button2.Enabled = (comboBox1.SelectedItem != null);
        }


        private void label1_Click(object sender, EventArgs e) { }

        private void label2_Click(object sender, EventArgs e) { }

        private void label3_Click(object sender, EventArgs e) { }



        private void button2_Click(object sender, EventArgs e) 
        {

            if (comboBox1.SelectedItem == null || !(comboBox1.SelectedItem is Tren trenSeleccionado))
            {
                MessageBox.Show("Por favor, seleccione un tren de la lista desplegable.", "Seleccionar Tren", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                richTextBox1.Text = ""; 
                return;
            }

            StringBuilder infoTren = new StringBuilder();
            infoTren.AppendLine("--- Información del Tren ---");
            infoTren.AppendLine($"ID del Tren: {trenSeleccionado.IdTren}");
            infoTren.AppendLine($"Nombre (Generado): {trenSeleccionado.Nombre}");
            infoTren.AppendLine($"Tipo de Tren: {trenSeleccionado.TipoTren}");
            infoTren.AppendLine($"Kilometraje: {trenSeleccionado.Kilometraje:F2} km"); 
            infoTren.AppendLine($"Capacidad Total de Vagones: {trenSeleccionado.CapacidadVagones}");
            infoTren.AppendLine($"Cantidad de Vagones de Carga: {trenSeleccionado.CantidadVagonesCarga}");
            infoTren.AppendLine($"Cantidad de Vagones de Pasajeros: {trenSeleccionado.CantidadVagonesPasajeros}");
            infoTren.AppendLine($"Capacidad Total de Pasajeros: {trenSeleccionado.CantidadPasajerosTotal}");


            if (trenSeleccionado.RutaAsignada != null)
            {
                infoTren.AppendLine("--- Ruta Asignada ---");
                infoTren.AppendLine($"ID de Ruta: {trenSeleccionado.RutaAsignada.IdRuta}");
                infoTren.AppendLine($"Origen: {trenSeleccionado.RutaAsignada.EstacionDePartida?.NombreEstacion?[0] ?? "Desconocido"}"); 
                infoTren.AppendLine($"Destino: {trenSeleccionado.RutaAsignada.EstacionDeLlegada?.NombreEstacion?[0] ?? "Desconocido"}"); 
                infoTren.AppendLine($"Distancia: {trenSeleccionado.RutaAsignada.DistanciaKm} km");
                infoTren.AppendLine($"Horario Salida: {trenSeleccionado.RutaAsignada.FechaHoraDeSalida}");
                infoTren.AppendLine($"Horario Llegada: {trenSeleccionado.RutaAsignada.FechaHoraDeLlegada}");
            }
            else
            {
                infoTren.AppendLine("--- Ruta Asignada: Ninguna ---");
            }

            richTextBox1.Text = infoTren.ToString();
            richTextBox1.Enabled = true; 
        }

        private void button3_Click(object sender, EventArgs e) 
        {

            GestionTrenes_Form9 gestionTrenesForm = new GestionTrenes_Form9(); 
            gestionTrenesForm.Show(); 
            this.Close(); 
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}

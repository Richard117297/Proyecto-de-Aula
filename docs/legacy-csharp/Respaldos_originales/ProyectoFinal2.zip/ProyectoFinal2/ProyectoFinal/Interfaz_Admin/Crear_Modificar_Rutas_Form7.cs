﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class Crear_Modificar_Rutas_Form7 : Form
    {
        private string rutaArchivoRutas = @"Base de datos JSON\Ruta.json";

        public Crear_Modificar_Rutas_Form7()
        {
            InitializeComponent();

        }


        private void Crear_Modificar_Rutas_Form7_Load(object sender, EventArgs e)
        {
            CargarEstaciones();

            comboBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox1.Enabled = false;
            textBox5.Enabled = false;
            button2.Enabled = false;
            button1.Enabled = false;

            textBox3.Text = "";
            textBox1.Text = "";
            textBox5.Text = "";
        }


        private void CargarEstaciones()
        {
            comboBox1.Items.Clear();

            if (DatosGlobales.ListaGlobalDeBoletos != null && DatosGlobales.ListaGlobalDeBoletos.Valor != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones != null)
            {
                foreach (var nodoEstacionGrafo in DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones)
                {
                    if (nodoEstacionGrafo != null && nodoEstacionGrafo.Estacion != null && nodoEstacionGrafo.Estacion.NombreEstacion != null && nodoEstacionGrafo.Estacion.NombreEstacion.Length > 0)
                    {
                        string nombreEstacion = nodoEstacionGrafo.Estacion.NombreEstacion[0]; 
                                                                                              
                        comboBox1.Items.Add(nombreEstacion);
                    }
                }
                comboBox1.Enabled = true;
            }
            else
            {

                MessageBox.Show("Error interno: Datos globales o grafo no disponibles.", "Error de Carga", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox1.Enabled = false;
            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            textBox3.Text = "";
            textBox1.Text = "";
            textBox5.Text = "";
            comboBox2.Enabled = false;
            button2.Enabled = false;
            button1.Enabled = false;

            if (comboBox1.SelectedItem != null && DatosGlobales.ListaGlobalDeBoletos != null && DatosGlobales.ListaGlobalDeBoletos.Valor != null && DatosGlobales.ListaGlobalDeBoletos.Valor.MatrizAdyacencia != null)
            {
                string nombreEstacionOrigen = comboBox1.SelectedItem.ToString();
                int indiceOrigen = -1;


                for (int i = 0; i < DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones.Count; i++)
                {
                    if (DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[i].Estacion != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[i].Estacion.NombreEstacion != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[i].Estacion.NombreEstacion.Length > 0 && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[i].Estacion.NombreEstacion[0] == nombreEstacionOrigen)
                    {
                        indiceOrigen = i;
                        break;
                    }
                }

                if (indiceOrigen != -1)
                {
                    bool rutasEncontradas = false;
                    for (int j = 0; j < DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones.Count; j++)
                    {
                        if (DatosGlobales.ListaGlobalDeBoletos.Valor.MatrizAdyacencia[indiceOrigen, j] != int.MaxValue && indiceOrigen != j)
                        {
                            if (DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[j].Estacion != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[j].Estacion.NombreEstacion != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[j].Estacion.NombreEstacion.Length > 0)
                            {
                                string nombreEstacionDestino = DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[j].Estacion.NombreEstacion[0];
                                comboBox2.Items.Add($"{nombreEstacionOrigen} - {nombreEstacionDestino}");
                                rutasEncontradas = true;
                            }
                        }
                    }

                    if (rutasEncontradas)
                    {
                        comboBox2.Enabled = true;
                        button2.Enabled = true;
                        if (comboBox2.Items.Count > 0)
                        {
                            comboBox2.SelectedIndex = 0;
                        }
                    }
                    else
                    {
                        MessageBox.Show($"No hay rutas directas disponibles desde {nombreEstacionOrigen}.", "Rutas No Encontradas", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox3.Text = "";
            textBox1.Text = "";
            textBox5.Text = "";
            button1.Enabled = false;
        }



        private void button2_Click(object sender, EventArgs e) 
        {
            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione una ruta disponible.", "Seleccionar Ruta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            if (DatosGlobales.ListaGlobalDeBoletos == null || DatosGlobales.ListaGlobalDeBoletos.Valor == null || DatosGlobales.ListaGlobalDeBoletos.Valor.MatrizAdyacencia == null || DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones == null)
            {
                MessageBox.Show("Error interno: Datos globales o grafo no disponibles.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string rutaSeleccionada = comboBox2.SelectedItem.ToString();
            string[] estacionesRuta = rutaSeleccionada.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

            if (estacionesRuta.Length == 2)
            {
                string nombreOrigen = estacionesRuta[0];
                string nombreDestino = estacionesRuta[1];

                int indiceOrigen = -1;
                int indiceDestino = -1;

                for (int i = 0; i < DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones.Count; i++)
                {
                    if (DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[i].Estacion != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[i].Estacion.NombreEstacion != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[i].Estacion.NombreEstacion.Length > 0)
                    {
                        if (DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[i].Estacion.NombreEstacion[0] == nombreOrigen)
                        {
                            indiceOrigen = i;
                        }
                        if (DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones[i].Estacion.NombreEstacion[0] == nombreDestino)
                        {
                            indiceDestino = i;
                        }
                    }
                }

                if (indiceOrigen != -1 && indiceDestino != -1 && DatosGlobales.ListaGlobalDeBoletos.Valor.MatrizAdyacencia[indiceOrigen, indiceDestino] != int.MaxValue)
                {

                    int distancia = DatosGlobales.ListaGlobalDeBoletos.Valor.CalcularDistancia(indiceOrigen, indiceDestino);
                    textBox3.Text = distancia.ToString();


                    string idRutaGenerado = Guid.NewGuid().ToString("N").Substring(0, 8).ToUpper();
                    textBox5.Text = idRutaGenerado;


                    textBox1.Text = "Horario Pendiente";


                    button1.Enabled = true;
                }
                else
                {
                    MessageBox.Show($"No se pudo encontrar la distancia para la ruta {rutaSeleccionada}. Verifique la matriz del grafo.", "Error de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox3.Text = "";
                    textBox1.Text = "";
                    textBox5.Text = "";
                    button1.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Formato de ruta seleccionado inválido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox3.Text = "";
                textBox1.Text = "";
                textBox5.Text = "";
                button1.Enabled = false;
            }
        }


        private void button1_Click(object sender, EventArgs e) 
        {
            if (string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox5.Text) || comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Por favor, actualice la información de la ruta antes de publicar.", "Información Incompleta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (DatosGlobales.ListaGlobalDeRutasRecomendadas == null || DatosGlobales.ListaGlobalDeBoletos?.Valor?.Estaciones == null)
            {
                MessageBox.Show("Error interno: Lista de rutas o estaciones no disponibles en Datos Globales.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string rutaSeleccionada = comboBox2.SelectedItem.ToString();
            string[] estacionesRuta = rutaSeleccionada.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

            if (estacionesRuta.Length == 2)
            {
                string nombreOrigen = estacionesRuta[0];
                string nombreDestino = estacionesRuta[1];
                string idRuta = textBox5.Text;
                string horario = textBox1.Text;
                int distancia;
                if (!int.TryParse(textBox3.Text, out distancia))
                {
                    MessageBox.Show("Error al obtener la distancia.", "Error de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Estacion estacionPartida = null;
                Estacion estacionLlegada = null;

                foreach (var nodoEstacionGrafo in DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones)
                {
                    if (nodoEstacionGrafo != null && nodoEstacionGrafo.Estacion != null && nodoEstacionGrafo.Estacion.NombreEstacion != null && nodoEstacionGrafo.Estacion.NombreEstacion.Length > 0)
                    {
                        if (nodoEstacionGrafo.Estacion.NombreEstacion[0] == nombreOrigen)
                        {
                            estacionPartida = nodoEstacionGrafo.Estacion;
                        }
                        if (nodoEstacionGrafo.Estacion.NombreEstacion[0] == nombreDestino)
                        {
                            estacionLlegada = nodoEstacionGrafo.Estacion;
                        }
                    }
                    if (estacionPartida != null && estacionLlegada != null) break;
                }

                if (estacionPartida != null && estacionLlegada != null)
                {
                    Ruta nuevaRuta = new Ruta(estacionPartida, estacionLlegada, distancia, horario, idRuta);

                    DatosGlobales.ListaGlobalDeRutasRecomendadas.addRuta(nuevaRuta);

                    
                    List<Ruta> rutasActuales = DatosGlobales.ListaGlobalDeRutasRecomendadas.GetAllRutas();
                    MessageBox.Show($"Intentando guardar. Número de rutas en la lista: {rutasActuales.Count}", "Depuración Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Ruta.GuardarDatos(rutaArchivoRutas, rutasActuales);

                    MessageBox.Show($"Ruta {idRuta} ({nombreOrigen} - {nombreDestino}) publicada y guardada exitosamente.", "Ruta Publicada", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    comboBox1.SelectedItem = null;
                    comboBox2.Items.Clear();
                    textBox3.Text = "";
                    textBox1.Text = "";
                    textBox5.Text = "";
                    comboBox2.Enabled = false;
                    button2.Enabled = false;
                    button1.Enabled = false;
                    CargarEstaciones();

                   

                }
                else
                {
                    MessageBox.Show("Error interno: No se encontraron las estaciones seleccionadas.", "Error de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Formato de ruta seleccionado inválido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


 
        private void button3_Click(object sender, EventArgs e) 
        {
            GestionRutas_Horarios_Form6 formAnterior = new GestionRutas_Horarios_Form6(); 
            formAnterior.Show();
            this.Close(); 
        }

       
        private void label3_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
    }
}

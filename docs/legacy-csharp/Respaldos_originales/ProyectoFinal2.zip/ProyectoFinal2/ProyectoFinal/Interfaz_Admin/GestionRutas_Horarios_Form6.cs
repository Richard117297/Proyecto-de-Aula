﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class GestionRutas_Horarios_Form6 : Form
    {
        public GestionRutas_Horarios_Form6()
        {
            InitializeComponent();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (DatosGlobales.ListaGlobalDeBoletos == null || DatosGlobales.ListaGlobalDeBoletos.Valor == null)
            {
                MessageBox.Show("Error fatal: Los datos globales del sistema (grafo) no están inicializados.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            Crear_Modificar_Rutas_Form7 crearModificarRutasForm = new Crear_Modificar_Rutas_Form7();
            crearModificarRutasForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (DatosGlobales.ListaGlobalDeBoletos == null || DatosGlobales.ListaGlobalDeBoletos.Valor == null || DatosGlobales.ListaGlobalDeBoletos.Valor.ListaRutas == null)
            {
                MessageBox.Show("Error fatal: Los datos globales del sistema (rutas publicadas) no están inicializados.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            Recomendacion_Rutas_Form8 recomendacionRutasForm = new Recomendacion_Rutas_Form8();
            recomendacionRutasForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Main_Admin_Form2 formAnterior = new Main_Admin_Form2(); 
            formAnterior.Show();
            this.Close();
        }

        private void GestionRutas_Horarios_Form6_Load(object sender, EventArgs e)
        {
            if (DatosGlobales.ListaGlobalDeBoletos?.Valor?.ListaRutas != null)
            {
                List<Ruta> rutasPublicadas = DatosGlobales.ListaGlobalDeBoletos.Valor.ListaRutas.GetAllRutas();
                foreach (var ruta in rutasPublicadas)
                {
                    Console.WriteLine(ruta.GetInfoCompleta());
                }
            }
            else
            {
                Console.WriteLine("No hay rutas disponibles.");
            }
        }
    }
}

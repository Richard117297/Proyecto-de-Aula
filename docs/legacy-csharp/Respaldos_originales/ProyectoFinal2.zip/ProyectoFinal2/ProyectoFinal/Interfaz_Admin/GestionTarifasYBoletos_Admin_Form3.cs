﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class GestionTarifasYBoletos_Admin_Form3 : Form
    {
        public GestionTarifasYBoletos_Admin_Form3()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (DatosGlobales.ListaGlobalDeBoletos == null)
            {
                MessageBox.Show("Error fatal: Los datos globales del sistema no están inicializados.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close(); 
                return;
            }

            RegistrarInformacionBoleto_Form5 registrarBoletoForm = new RegistrarInformacionBoleto_Form5();
            registrarBoletoForm.Show();
            this.Hide();

        }
        private void button2_Click(object sender, EventArgs e)
        {
            GestionValorPasaje_Admin_Form4 gestionValorPasajeForm = new GestionValorPasaje_Admin_Form4();
            gestionValorPasajeForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Main_Admin_Form2 mainAdminForm = new Main_Admin_Form2(); 
            mainAdminForm.Show();
            this.Close();
        }

        private void GestionTarifasYBoletos_Admin_Form3_Load(object sender, EventArgs e)
        {

        }
    }
}

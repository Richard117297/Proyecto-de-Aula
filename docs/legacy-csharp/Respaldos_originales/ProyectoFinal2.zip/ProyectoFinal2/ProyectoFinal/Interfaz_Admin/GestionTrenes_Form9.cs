﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProyectoFinal.Interfaz_Admin;

namespace Interfaz_Administrador
{
    public partial class GestionTrenes_Form9 : Form
    {
        public GestionTrenes_Form9()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            AgregarTren_Form10 agregarTrenForm = new AgregarTren_Form10();
            agregarTrenForm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            VerificarTren_Form11 verificarTrenForm = new VerificarTren_Form11();
            verificarTrenForm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AlmacenamientoDeTrenes_Form12 almacenamientoForm = new AlmacenamientoDeTrenes_Form12();
            almacenamientoForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Main_Admin_Form2 mainAdminForm = new Main_Admin_Form2();
            mainAdminForm.Show();
            this.Close();
        }

        private void GestionTrenes_Form9_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

            AgregarVagonAlTren_Form10_5 agregarVagonForm = new AgregarVagonAlTren_Form10_5();
            agregarVagonForm.Show();
            this.Hide();

        }
    }
}

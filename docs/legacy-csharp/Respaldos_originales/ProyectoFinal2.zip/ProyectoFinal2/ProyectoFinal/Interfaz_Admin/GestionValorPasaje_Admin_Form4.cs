﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Interfaz_Administrador
{
    public partial class GestionValorPasaje_Admin_Form4 : Form
    {
        private GrafoEstacion grafo;
        private ListaEnlazadaSimple_Boletos listaBoletos;


        public GestionValorPasaje_Admin_Form4()
        {
            InitializeComponent();

            string[] nombresEstaciones = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K" };
            
            grafo = new GrafoEstacion(nombresEstaciones.Length);

            foreach (string nombre in nombresEstaciones)
            {
                
                grafo.AddEstacion(new Estacion(nombre));
            }

            int?[,] distancias = new int?[,]
            {
            { null, 30, 40, 50, null, null, null, null, null, null, null },
            { 30, null, null, null, null, null, null, 80, 120, 110, null },
            { 40, null, null, null, null, null, null, null, null, null, null },
            { 50, null, null, null, 20, null, null, null, null, null, null },
            { null, null, null, 20, null, 65, null, null, null, null, null },
            { null, null, null, null, 65, null, 80, null, null, null, null },
            { null, null, null, null, null, 80, null, 30, 145, null, null },
            { null, 80, null, null, null, null, 30, null, null, null, null },
            { null, 120, null, null, null, null, 145, null, null, null, null },
            { null, 110, null, null, null, null, null, null, null, null, null },
            { null, null, null, null, null, null, null, null, null, null, null }
            };

            
            for (int i = 0; i < nombresEstaciones.Length; i++)
            {
                for (int j = i + 1; j < nombresEstaciones.Length; j++) 
                {
                    if (distancias[i, j].HasValue)
                    {
                        grafo.AddRutaNoDirigida(i, j, distancias[i, j].Value);
                    }
                }
            }

            listaBoletos = new ListaEnlazadaSimple_Boletos();

            listaBoletos.Valor = grafo;
           
        }


       
        private void GestionValorPasaje_Admin_Form4_Load(object sender, EventArgs e)
        {
            
            CargarDatosIniciales();
        }


        
        private void CargarDatosIniciales()
        {
            comboBox1.Items.Clear(); 
            comboBox2.Items.Clear(); 


            if (listaBoletos?.Valor?.Estaciones != null)
            {
                foreach (var nodo in listaBoletos.Valor.Estaciones) 
                {

                    if (nodo?.Estacion?.NombreEstacion != null && nodo.Estacion.NombreEstacion.Length > 0)
                    {
                        comboBox1.Items.Add(nodo.Estacion.NombreEstacion[0]);
                        comboBox2.Items.Add(nodo.Estacion.NombreEstacion[0]);
                    }
                }
            }
            else
            {
                
                MessageBox.Show("Error al cargar datos de estaciones. Verifique la inicialización del grafo y la lista de boletos.");
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {

            if (double.TryParse(textBox5.Text, out double valorPasajeCalculado))
            {
                TipoBoletoEnum tipoSeleccionado = TipoBoletoEnum.Desconocido;
                try
                {
                    TipoBoleto tipoB = new TipoBoleto();
                    tipoSeleccionado = tipoB.SeleccionarTipoBoleto(textBox3.Text.Trim());
                }
                catch (Exception ex) 
                {
                    MessageBox.Show(ex.Message);
                    return; 
                }


                Boleto nuevoBoleto = new Boleto 
                {
                    
                    IdRegistro = Guid.NewGuid().ToString(), 
                    ValorPasaje = (int)valorPasajeCalculado, 
                    TipoDeBoleta = tipoSeleccionado
 
                };


                if (listaBoletos != null) 
                {
                    
                    listaBoletos.AddBoleto(nuevoBoleto);
                    MessageBox.Show($"Boleto calculado y agregado a la lista con ID: {nuevoBoleto.IdRegistro}.");

                    
                    comboBox1.SelectedItem = null;
                    comboBox2.SelectedItem = null;
                    textBox1.Clear();
                    textBox3.Clear();
                    textBox5.Clear();
                }
                else
                {
                    MessageBox.Show("Error interno: La lista de boletos no está inicializada correctamente.");
                }
            }
            else
            {
                MessageBox.Show("Error al obtener el valor del pasaje calculado desde el campo.");
            }

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Debe seleccionar estación de partida y llegada.");
                return;
            }

            
            string nombreOrigen = comboBox1.SelectedItem.ToString();
            string nombreDestino = comboBox2.SelectedItem.ToString();

            
            int origen = ObtenerIndiceEstacion(nombreOrigen); 
            int destino = ObtenerIndiceEstacion(nombreDestino); 


            if (origen == -1 || destino == -1)
            {
                MessageBox.Show("Error al encontrar los índices de las estaciones seleccionadas en el grafo.");
                return;
            }


            int distancia = -1; 
            if (listaBoletos?.Valor != null)
            {
                distancia = listaBoletos.Valor.CalcularDistancia(origen, destino); 
            }
            else
            {
                MessageBox.Show("Error: El grafo no está accesible para calcular la distancia.");
                return;
            }


            if (distancia == int.MaxValue || distancia < 0) 
            {
                MessageBox.Show($"No hay ruta disponible entre {nombreOrigen} y {nombreDestino}.");
                textBox1.Text = ""; 
                textBox5.Text = ""; 
                return;
            }

            
            textBox1.Text = distancia.ToString();

            CalcularYMostrarPrecio(); 
        }

        private void button3_Click(object sender, EventArgs e)
        {

            GestionTarifasYBoletos_Admin_Form3 formAnterior = new GestionTarifasYBoletos_Admin_Form3();

            if (formAnterior == null)
            {
                MessageBox.Show("Error: No se pudo crear el formulario anterior.");
                return;
            }

            formAnterior.Show();
            this.Close();

        }



        
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            textBox1.Text = "";
            textBox5.Text = "";
        }

        
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs args) 
        {

            textBox1.Text = "";
            textBox5.Text = "";
        }

        
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

            CalcularYMostrarPrecio();
        }


        private void textBox3_TextChanged(object sender, EventArgs e) 
        {

            CalcularYMostrarPrecio();
        }


        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { } 



        private void CalcularYMostrarPrecio()
        {
            
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox3.Text))
            {
                textBox5.Text = ""; 
                return;
            }

           
            int distancia;
            if (!int.TryParse(textBox1.Text, out distancia))
            {

                textBox5.Text = "";
                return;
            }


            if (distancia <= 0)
            {
                textBox5.Text = "";
                return;
            }



            string tipoBoletoTexto = textBox3.Text.Trim();
            TipoBoleto tipoB = new TipoBoleto(); 
            TipoBoletoEnum tipoSeleccionado; 

            try
            {

                tipoSeleccionado = tipoB.SeleccionarTipoBoleto(tipoBoletoTexto);
            }
            catch (Exception ex)
            {

                textBox5.Text = "";
                MessageBox.Show(ex.Message);
                return;
            }


            int origen = ObtenerIndiceEstacion(comboBox1.SelectedItem?.ToString()); 
            int destino = ObtenerIndiceEstacion(comboBox2.SelectedItem?.ToString()); 


            if (origen == -1 || destino == -1)
            {
                MessageBox.Show("Error interno: No se pudieron obtener los índices de las estaciones para calcular el precio base.");
                textBox5.Text = "";
                return;
            }


            double precioBaseDistancia = listaBoletos.CalcularPrecioBoleto(origen, destino);



            if (precioBaseDistancia <= 0 && distancia != 0)
            {
                MessageBox.Show("Error al calcular el precio base por distancia.");
                textBox5.Text = "";
                return;
            }

            if (distancia == 0) precioBaseDistancia = 0;



            double precioFinal = precioBaseDistancia; 

            switch (tipoSeleccionado)
            {
                case TipoBoletoEnum.Premium:
                    precioFinal *= 1.5;
                    break;
                case TipoBoletoEnum.Ejecutivo:
                    precioFinal *= 1.2;
                    break;
                case TipoBoletoEnum.Estandar:

                    break;
                case TipoBoletoEnum.Desconocido:

                    precioFinal = 0;
                    break;
            }


            textBox5.Text = precioFinal.ToString("F2");
        }

        private int ObtenerIndiceEstacion(string nombreEstacion)
        {
            if (string.IsNullOrEmpty(nombreEstacion) || listaBoletos?.Valor?.Estaciones == null)
            {
                return -1; 
            }


            for (int i = 0; i < listaBoletos.Valor.Estaciones.Count; i++)
            {

                if (listaBoletos.Valor.Estaciones[i]?.Estacion?.NombreEstacion != null && listaBoletos.Valor.Estaciones[i].Estacion.NombreEstacion.Length > 0)
                {
                    
                    if (listaBoletos.Valor.Estaciones[i].Estacion.NombreEstacion[0].ToString().Equals(nombreEstacion, StringComparison.OrdinalIgnoreCase))
                    {
                        return i; 
                    }
                }
            }
            return -1; 
        }
    }
}

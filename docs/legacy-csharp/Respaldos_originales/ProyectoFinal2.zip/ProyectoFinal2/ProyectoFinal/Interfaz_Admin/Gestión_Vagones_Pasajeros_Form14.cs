﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class Gestión_Vagones_Pasajeros_Form14 : Form
    {
        public Gestión_Vagones_Pasajeros_Form14()
        {
            InitializeComponent();
        }

        private void Gestión_Vagones_Pasajeros_Form14_Load(object sender, EventArgs e)
        {
            LimpiarCampos();
            DeshabilitarControles();
 
            button5.Enabled = true;
        }

        private void LimpiarCampos()
        {
            textBox1.Text = "";
            textBox3.Text = "";

            textBox2.Text = "";
            textBox6.Text = "";

            textBox4.Text = "";
            textBox7.Text = "";

            textBox5.Text = "";
            textBox8.Text = "";
        }

        private void DeshabilitarControles()
        {
            textBox1.Enabled = false;
            textBox3.Enabled = false;
            textBox2.Enabled = false;
            textBox6.Enabled = false;
            textBox4.Enabled = false;
            textBox7.Enabled = false;
            textBox5.Enabled = false;
            textBox8.Enabled = false;

            comboBox1.Enabled = false;
            comboBox2.Enabled = false;

            button2.Enabled = false; 
            button4.Enabled = false; 
            button1.Enabled = false; 

        }

        private void button5_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            DeshabilitarControles();

            CargarEstacionesEnDesplegables();

            if (comboBox1.Items.Count > 0)
            {
                comboBox1.Enabled = true;
                comboBox2.Enabled = true;
                comboBox1.SelectedIndex = 0;
                comboBox2.SelectedIndex = 0;

                button2.Enabled = true; 
                button4.Enabled = true; 
            }
            else
            {
                MessageBox.Show("No se pudieron cargar las estaciones. Asegúrese de que el grafo de estaciones está inicializado y contiene estaciones válidas.", "Error de Carga", MessageBoxButtons.OK, MessageBoxIcon.Error);
                button2.Enabled = false;
                button4.Enabled = false;
            }
        }

        private void CargarEstacionesEnDesplegables()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            if (DatosGlobales.ListaGlobalDeBoletos != null && DatosGlobales.ListaGlobalDeBoletos.Valor != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones != null)
            {
                foreach (var nodoEstacionGrafo in DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones)
                {
                    if (nodoEstacionGrafo != null && nodoEstacionGrafo.Estacion != null && nodoEstacionGrafo.Estacion.NombreEstacion != null && nodoEstacionGrafo.Estacion.NombreEstacion.Length > 0)
                    {
                        string nombreEstacion = nodoEstacionGrafo.Estacion.NombreEstacion[0];

                        comboBox1.Items.Add(nombreEstacion);
                        comboBox2.Items.Add(nombreEstacion);
                    }
                }
            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            textBox1.Text = "";
            textBox3.Text = "";
            textBox1.Enabled = false;
            textBox3.Enabled = false;

            button1.Enabled = false;
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            textBox2.Text = "";
            textBox6.Text = "";
            textBox4.Text = "";
            textBox7.Text = "";
            textBox5.Text = "";
            textBox8.Text = "";
            textBox2.Enabled = false; textBox6.Enabled = false;
            textBox4.Enabled = false; textBox7.Enabled = false;
            textBox5.Enabled = false; textBox8.Enabled = false;

            button1.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione una estación en el desplegable general para calcular.", "Seleccionar Estación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Text = ""; textBox3.Text = "";
                textBox1.Enabled = false; textBox3.Enabled = false;
                button1.Enabled = false;
                return;
            }

            if (DatosGlobales.ListaGlobalDeBoletos == null)
            {
                MessageBox.Show("Error interno: Lista global de boletos comprados no disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LimpiarCampos();
                DeshabilitarControles();
                button5.Enabled = true;
                return;
            }

            List<Boleto> todosBoletos = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();

            if (todosBoletos == null || todosBoletos.Count == 0)
            {
                MessageBox.Show("No hay boletos comprados registrados en el sistema.", "Sin Datos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox1.Text = "0"; textBox3.Text = "0";
                textBox1.Enabled = true; textBox3.Enabled = true;

                button1.Enabled = false;
                return;
            }

            List<Boleto> boletosRegistrados = todosBoletos.Where(b => b.EsRegistrado).ToList();

            if (boletosRegistrados.Count == 0)
            {
                MessageBox.Show("No hay boletos registrados por el administrador.", "Sin Datos Registrados", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox1.Text = "0"; textBox3.Text = "0";
                textBox1.Enabled = true; textBox3.Enabled = true;

                button1.Enabled = false; 
                return;
            }

            string estacionGeneral = comboBox1.SelectedItem.ToString();
            int comprasGenerales = 0;
            int pasajerosGenerales = 0;

            foreach (Boleto boleto in boletosRegistrados)
            {
                if (!string.IsNullOrEmpty(boleto.EstacionOrigen) &&
                    boleto.EstacionOrigen.Equals(estacionGeneral, StringComparison.OrdinalIgnoreCase))
                {
                    comprasGenerales++;
                    pasajerosGenerales++;
                }
            }

            textBox1.Text = comprasGenerales.ToString();
            textBox3.Text = pasajerosGenerales.ToString();
            textBox1.Enabled = true;
            textBox3.Enabled = true;

            HabilitarBotonGuardarSiHayDatos();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione una estación en el desplegable por tipo para calcular.", "Seleccionar Estación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.Text = ""; textBox6.Text = "";
                textBox4.Text = ""; textBox7.Text = "";
                textBox5.Text = ""; textBox8.Text = "";
                textBox2.Enabled = false; textBox6.Enabled = false;
                textBox4.Enabled = false; textBox7.Enabled = false;
                textBox5.Enabled = false; textBox8.Enabled = false;
                button1.Enabled = false;
                return;
            }

            if (DatosGlobales.ListaGlobalDeBoletos == null)
            {
                MessageBox.Show("Error interno: Lista global de boletos comprados no disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LimpiarCampos();
                DeshabilitarControles();
                button5.Enabled = true; 
                return;
            }

            List<Boleto> todosBoletos = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();

            if (todosBoletos == null || todosBoletos.Count == 0)
            {
                MessageBox.Show("No hay boletos comprados registrados en el sistema.", "Sin Datos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox2.Text = "0"; textBox6.Text = "0";
                textBox4.Text = "0"; textBox7.Text = "0";
                textBox5.Text = "0"; textBox8.Text = "0";
                textBox2.Enabled = true; textBox6.Enabled = true;
                textBox4.Enabled = true; textBox7.Enabled = true;
                textBox5.Enabled = true; textBox8.Enabled = true;

                button1.Enabled = false; 
                return;
            }

            List<Boleto> boletosRegistrados = todosBoletos.Where(b => b.EsRegistrado).ToList();

            if (boletosRegistrados.Count == 0)
            {
                MessageBox.Show("No hay boletos registrados por el administrador.", "Sin Datos Registrados", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox2.Text = "0"; textBox6.Text = "0";
                textBox4.Text = "0"; textBox7.Text = "0";
                textBox5.Text = "0"; textBox8.Text = "0";
                textBox2.Enabled = true; textBox6.Enabled = true;
                textBox4.Enabled = true; textBox7.Enabled = true;
                textBox5.Enabled = true; textBox8.Enabled = true;

                button1.Enabled = false; 
                return;
            }

            string estacionPorTipo = comboBox2.SelectedItem.ToString();

            int comprasPremium = 0; int pasajerosPremium = 0;
            int comprasEjecutivo = 0; int pasajerosEjecutivo = 0;
            int comprasEstandar = 0; int pasajerosEstandar = 0;

            foreach (Boleto boleto in boletosRegistrados)
            {
                if (!string.IsNullOrEmpty(boleto.EstacionOrigen) &&
                    boleto.EstacionOrigen.Equals(estacionPorTipo, StringComparison.OrdinalIgnoreCase))
                {
                    if (boleto.TipoDeBoleta != TipoBoletoEnum.Desconocido)
                    {
                        if (boleto.TipoDeBoleta == TipoBoletoEnum.Premium)
                        {
                            comprasPremium++;
                            pasajerosPremium++;
                        }
                        else if (boleto.TipoDeBoleta == TipoBoletoEnum.Ejecutivo)
                        {
                            comprasEjecutivo++;
                            pasajerosEjecutivo++;
                        }
                        else if (boleto.TipoDeBoleta == TipoBoletoEnum.Estandar)
                        {
                            comprasEstandar++;
                            pasajerosEstandar++;
                        }
                    }
                }
            }

            textBox2.Text = comprasPremium.ToString();
            textBox6.Text = pasajerosPremium.ToString();

            textBox4.Text = comprasEjecutivo.ToString();
            textBox7.Text = pasajerosEjecutivo.ToString();

            textBox5.Text = comprasEstandar.ToString();
            textBox8.Text = pasajerosEstandar.ToString();

            textBox2.Enabled = true; textBox6.Enabled = true;
            textBox4.Enabled = true; textBox7.Enabled = true;
            textBox5.Enabled = true; textBox8.Enabled = true;


            HabilitarBotonGuardarSiHayDatos();
        }


        private void HabilitarBotonGuardarSiHayDatos()
        {
            bool hayDatosGeneral = !string.IsNullOrEmpty(textBox1.Text) || !string.IsNullOrEmpty(textBox3.Text);
            bool hayDatosPorTipo = !string.IsNullOrEmpty(textBox2.Text) || !string.IsNullOrEmpty(textBox6.Text) ||
                                   !string.IsNullOrEmpty(textBox4.Text) || !string.IsNullOrEmpty(textBox7.Text) ||
                                   !string.IsNullOrEmpty(textBox5.Text) || !string.IsNullOrEmpty(textBox8.Text);

            button1.Enabled = hayDatosGeneral || hayDatosPorTipo;
        }

        private void button1_Click(object sender, EventArgs e)
        {
 
            if ((string.IsNullOrEmpty(textBox1.Text) && string.IsNullOrEmpty(textBox3.Text)) &&
                (string.IsNullOrEmpty(textBox2.Text) && string.IsNullOrEmpty(textBox6.Text) &&
                 string.IsNullOrEmpty(textBox4.Text) && string.IsNullOrEmpty(textBox7.Text) &&
                 string.IsNullOrEmpty(textBox5.Text) && string.IsNullOrEmpty(textBox8.Text)))
            {
                MessageBox.Show("No hay datos de compras o pasajeros calculados para guardar.", "Sin Datos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            StringBuilder infoAGuardar = new StringBuilder();
            infoAGuardar.AppendLine("--- Reporte de Gestión de Pasajeros ---");
            infoAGuardar.AppendLine($"Fecha del Reporte: {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
            infoAGuardar.AppendLine("--------------------------------------");

            if (comboBox1.SelectedItem != null && (!string.IsNullOrEmpty(textBox1.Text) || !string.IsNullOrEmpty(textBox3.Text)))
            {
                string estacionGeneral = comboBox1.SelectedItem.ToString();
                infoAGuardar.AppendLine($"Estación Seleccionada (General): {estacionGeneral}");
                infoAGuardar.AppendLine($"Total de Compras: {textBox1.Text}");
                infoAGuardar.AppendLine($"Total de Pasajeros: {textBox3.Text}");
                infoAGuardar.AppendLine("--------------------------------------");
            }

            if (comboBox2.SelectedItem != null && (!string.IsNullOrEmpty(textBox2.Text) || !string.IsNullOrEmpty(textBox6.Text) ||
                                                   !string.IsNullOrEmpty(textBox4.Text) || !string.IsNullOrEmpty(textBox7.Text) ||
                                                   !string.IsNullOrEmpty(textBox5.Text) || !string.IsNullOrEmpty(textBox8.Text)))
            {
                string estacionPorTipo = comboBox2.SelectedItem.ToString();
                infoAGuardar.AppendLine($"Estación Seleccionada (Por Tipo): {estacionPorTipo}");
                infoAGuardar.AppendLine($"Compras Premium: {textBox2.Text} | Pasajeros Premium: {textBox6.Text}");
                infoAGuardar.AppendLine($"Compras Ejecutivo: {textBox4.Text} | Pasajeros Ejecutivo: {textBox7.Text}");
                infoAGuardar.AppendLine($"Compras Estandar: {textBox5.Text} | Pasajeros Estandar: {textBox8.Text}");
                infoAGuardar.AppendLine("--------------------------------------");
            }


            MessageBox.Show("La información de cantidad de pasajeros ha sido procesada y está lista para ser guardada (lógica de guardado pendiente).\n\n" + infoAGuardar.ToString(), "Guardado (Lógica Pendiente)", MessageBoxButtons.OK, MessageBoxIcon.Information);


            LimpiarCampos();
            DeshabilitarControles();
            button5.Enabled = true; 
        }

        private void button3_Click(object sender, EventArgs e)
        {
 
            Informacion_Trenes_Form13 formAnterior = new Informacion_Trenes_Form13();
            formAnterior.Show();
            this.Close();
        }


        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { } 
        private void label8_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { } 
        private void label7_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { } 
        private void label10_Click(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { } 
        private void label9_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { } 
        private void label4_Click(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void label12_Click(object sender, EventArgs e) { }
        private void textBox8_TextChanged(object sender, EventArgs e) { }
        private void label11_Click(object sender, EventArgs e) { }
        private void textBox7_TextChanged(object sender, EventArgs e) { }
    }
}

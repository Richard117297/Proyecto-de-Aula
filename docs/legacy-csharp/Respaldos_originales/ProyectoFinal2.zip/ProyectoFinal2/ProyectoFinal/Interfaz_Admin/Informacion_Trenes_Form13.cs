﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaz_Administrador
{
    public partial class Informacion_Trenes_Form13 : Form
    {
        public Informacion_Trenes_Form13()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Gestión_Vagones_Pasajeros_Form14 gestionVagonesForm = new Gestión_Vagones_Pasajeros_Form14(); 
            gestionVagonesForm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OrdenAbordaje_Form15 ordenAbordajeForm = new OrdenAbordaje_Form15(); 
            ordenAbordajeForm.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Main_Admin_Form2 mainAdminForm = new Main_Admin_Form2(); 
            mainAdminForm.Show(); 
            this.Close();
        }

        private void Informacion_Trenes_Form13_Load(object sender, EventArgs e)
        {

        }
    }
}

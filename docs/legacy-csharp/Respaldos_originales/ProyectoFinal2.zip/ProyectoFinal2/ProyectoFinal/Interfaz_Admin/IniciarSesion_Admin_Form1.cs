﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class IniciarSesion_Admin_Form1 : Form
    {
        private Administrador administrador;

        public IniciarSesion_Admin_Form1()
        {
            InitializeComponent();
            administrador = new Administrador("admin", "password", "12345");
        }



        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string usuario = textBox1.Text;
            string contrasena = textBox2.Text;


            bool inicioSesionExitoso = administrador.IniciarSesion(usuario, contrasena);

            if (inicioSesionExitoso)
            {

                if (DatosGlobales.ListaGlobalDeBoletos == null)
                {
                    MessageBox.Show("Error fatal: Los datos globales del sistema no están inicializados.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                    Application.Exit();
                    return;
                }
            
                Main_Admin_Form2 mainAdminForm = new Main_Admin_Form2();

                mainAdminForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Inicio de sesión fallido. Usuario o contraseña incorrectos.", "Error de inicio de sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = "";
                textBox2.Text = "";
                textBox1.Focus();
            }
        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 formInicio = new Form1(); 
            formInicio.Show();
            this.Close();
        }

        private void IniciarSesion_Admin_Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

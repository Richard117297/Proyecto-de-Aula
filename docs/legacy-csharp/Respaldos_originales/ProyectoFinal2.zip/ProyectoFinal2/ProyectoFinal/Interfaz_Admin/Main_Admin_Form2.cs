﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class Main_Admin_Form2 : Form
    {
        private string rutaArchivo = @"Base de datos JSON\Boleto.json";

        private string rutaArchivoRutas = @"Base de datos JSON\Ruta.json";

        private string rutaArchivoTrenes = @"Base de datos JSON\Tren.json";

        

        public Main_Admin_Form2()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GestionTrenes_Form9 gestionTrenesForm = new GestionTrenes_Form9();
            gestionTrenesForm.Show();
            this.Hide();
        }

        private void Main_Admin_Form2_Load(object sender, EventArgs e)
        {
            List<Boleto> boletosCargados = Boleto.CargarDatos(rutaArchivo);

            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {
                foreach (var boleto in boletosCargados)
                {

                    if (!DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos().Any(b => b.IdRegistro == boleto.IdRegistro))
                    {
                        DatosGlobales.ListaGlobalDeBoletos.AddBoleto(boleto);
                        
                    }
                }
            }


            List<Tren> trenesCargados = Tren.CargarDatos(rutaArchivoTrenes);
            if (DatosGlobales.ListaGlobalDeTrenes != null)
            {
                foreach (var tren in trenesCargados)
                {
                    if (DatosGlobales.ListaGlobalDeTrenes.BuscarTrenPorId(tren.IdTren) == null)
                    {
                        DatosGlobales.ListaGlobalDeTrenes.agregarTren(tren);
                        
                    }
                }
            }
            MessageBox.Show("Datos de los boletos, rutas y tren cargados correctamente.", "Carga Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Main_Admin_Form2_FormClosing(object sender, FormClosingEventArgs e)
        {

            List<Boleto> boletosAGuardar = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();
            Boleto.GuardarDatos(rutaArchivo, boletosAGuardar);


            List<Ruta> rutasAGuardar = DatosGlobales.ListaGlobalDeRutasRecomendadas?.GetAllRutas() ?? new List<Ruta>();
            Ruta.GuardarDatos(rutaArchivoRutas, rutasAGuardar);
            
           
             List<Tren> trenesAGuardar = DatosGlobales.ListaGlobalDeTrenes.GetAllTrenes();
                Tren.GuardarDatos(rutaArchivoTrenes, trenesAGuardar);
            

            MessageBox.Show("Datos guardados correctamente.", "Guardado Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (DatosGlobales.ListaGlobalDeBoletos == null)
            {
                MessageBox.Show("Error fatal: Los datos globales del sistema no están inicializados.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close(); 
                return;
            }

            GestionTarifasYBoletos_Admin_Form3 gestionTarifasForm = new GestionTarifasYBoletos_Admin_Form3();
            gestionTarifasForm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Informacion_Trenes_Form13 informacionTrenesForm = new Informacion_Trenes_Form13();
            informacionTrenesForm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (DatosGlobales.ListaGlobalDeBoletos == null)
            {
                MessageBox.Show("Error fatal: Los datos globales del sistema no están inicializados.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close(); 
                return;
            }

            GestionRutas_Horarios_Form6 gestionRutasForm = new GestionRutas_Horarios_Form6();
            gestionRutasForm.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 formInicio = new Form1(); 
            formInicio.Show();
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class OrdenAbordaje_Form15 : Form
    {
        private Cola_Prioridad_Pasajeros _ordenDeAbordajeActual;

        public OrdenAbordaje_Form15()
        {
            InitializeComponent();
            _ordenDeAbordajeActual = new Cola_Prioridad_Pasajeros();
        }

        private void OrdenAbordaje_Form15_Load(object sender, EventArgs e)
        {
            LimpiarCampos();
            DeshabilitarControlesIniciales();
            CargarEstacionesEnDesplegable();
        }

        private void LimpiarCampos()
        {
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            comboBox2.Items.Clear();
            textBox1.Text = "";
            richTextBox1.Clear();
            _ordenDeAbordajeActual = new Cola_Prioridad_Pasajeros();
        }

        private void DeshabilitarControlesIniciales()
        {
            comboBox2.Enabled = false;
            textBox1.Enabled = false;
            richTextBox1.Enabled = false;
            button2.Enabled = false; 
            button1.Enabled = false; 
                                    
        }

        private void CargarEstacionesEnDesplegable()
        {
            comboBox1.Items.Clear();
            if (DatosGlobales.ListaGlobalDeBoletos != null && DatosGlobales.ListaGlobalDeBoletos.Valor != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones != null)
            {
                foreach (var nodoEstacionGrafo in DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones)
                {
                    if (nodoEstacionGrafo != null && nodoEstacionGrafo.Estacion != null && nodoEstacionGrafo.Estacion.NombreEstacion != null && nodoEstacionGrafo.Estacion.NombreEstacion.Length > 0)
                    {
                        string nombreEstacion = nodoEstacionGrafo.Estacion.NombreEstacion[0];
                        comboBox1.Items.Add(nombreEstacion);
                    }
                }
                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No se pudieron cargar las estaciones desde el grafo.", "Error de Carga", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    comboBox1.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Error interno: El grafo de estaciones no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox1.Enabled = false;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            comboBox2.Enabled = false;
            textBox1.Text = "";
            richTextBox1.Clear();
            button2.Enabled = false; 
            button1.Enabled = false; 

            if (comboBox1.SelectedItem != null)
            {
                CargarTrenesEnDesplegable(comboBox1.SelectedItem.ToString());
            }
        }

        private void CargarTrenesEnDesplegable(string nombreEstacionSeleccionada)
        {
            comboBox2.Items.Clear();
            if (DatosGlobales.ListaGlobalDeTrenes != null && DatosGlobales.ListaGlobalDeTrenes.Cabeza != null)
            {
                NodoTren actual = DatosGlobales.ListaGlobalDeTrenes.Cabeza;
                bool trenesEncontrados = false;

                while (actual != null)
                {
                    if (actual.Tren != null && actual.Tren.RutaAsignada != null &&
                       actual.Tren.RutaAsignada.EstacionDePartida != null &&
                       actual.Tren.RutaAsignada.EstacionDePartida.NombreEstacion != null &&
                       actual.Tren.RutaAsignada.EstacionDePartida.NombreEstacion.Length > 0 &&
                       actual.Tren.RutaAsignada.EstacionDePartida.NombreEstacion[0].Equals(nombreEstacionSeleccionada, StringComparison.OrdinalIgnoreCase))
                    {
                        if (!string.IsNullOrEmpty(actual.Tren.IdTren))
                        {
                            comboBox2.Items.Add(actual.Tren.IdTren);
                            trenesEncontrados = true;
                        }
                    }
                    actual = actual.Siguiente;
                }

                if (trenesEncontrados)
                {
                    comboBox2.Enabled = true;
                }
                else
                {
                    MessageBox.Show($"No hay trenes con ruta asignada saliendo desde la estación '{nombreEstacionSeleccionada}'.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    comboBox2.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Error interno: La lista global de trenes no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox2.Enabled = false;
            }
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            richTextBox1.Clear();
           
            button2.Enabled = (comboBox1.SelectedItem != null && comboBox2.SelectedItem != null);
            button1.Enabled = false; 
        }

    
        private void button2_Click(object sender, EventArgs e) 
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione una estación de origen.", "Seleccionar Estación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un tren.", "Seleccionar Tren", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string nombreEstacionSeleccionada = comboBox1.SelectedItem.ToString();
            string idTrenSeleccionado = comboBox2.SelectedItem.ToString();

            textBox1.Text = "";
            richTextBox1.Clear();
            _ordenDeAbordajeActual = new Cola_Prioridad_Pasajeros();

            Tren trenEncontrado = DatosGlobales.ListaGlobalDeTrenes.BuscarTrenPorId(idTrenSeleccionado);

            if (trenEncontrado != null && trenEncontrado.RutaAsignada != null)
            {
                textBox1.Text = $"{trenEncontrado.RutaAsignada.EstacionDePartida.NombreEstacion[0]} a {trenEncontrado.RutaAsignada.EstacionDeLlegada.NombreEstacion[0]} (ID Ruta: {trenEncontrado.RutaAsignada.IdRuta})";
            }
            else
            {
                textBox1.Text = "Ruta no asignada o no encontrada";
            }

            if (DatosGlobales.ListaGlobalDeBoletos != null && DatosGlobales.ListaGlobalDeBoletos.Cabeza != null)
            {
                List<Boleto> boletosRegistrados = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos().Where(b => b.EsRegistrado).ToList();

                List<Boleto> boletosParaEsteAbordaje = boletosRegistrados
                    .Where(b => !string.IsNullOrEmpty(b.EstacionOrigen) &&
                                b.EstacionOrigen.Equals(nombreEstacionSeleccionada, StringComparison.OrdinalIgnoreCase) &&
                                !string.IsNullOrEmpty(b.IdTren) && 
                                b.IdTren.Equals(idTrenSeleccionado, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                if (boletosParaEsteAbordaje.Count > 0)
                {
                    Cola_Prioridad_Pasajeros colaTemporalParaPrioridad = new Cola_Prioridad_Pasajeros();

                    var boletosOrdenados = boletosParaEsteAbordaje
                        .OrderBy(b => colaTemporalParaPrioridad.ObtenerPrioridadDesdeEnum(b.TipoDeBoleta))
                        .ToList();

                    StringBuilder ordenVisual = new StringBuilder();
                    ordenVisual.AppendLine($"--- Orden de Abordaje para Tren {idTrenSeleccionado} en Estación {nombreEstacionSeleccionada} ---");
                    ordenVisual.AppendLine();

                   
                    if (DatosGlobales.ListaGlobalDePasajeros != null) 
                    {
                        foreach (Boleto boleto in boletosOrdenados)
                        {
                            int prioridadNumerica = colaTemporalParaPrioridad.ObtenerPrioridadDesdeEnum(boleto.TipoDeBoleta);
                            string nombreCompletoPasajero = $"{boleto.NombrePasajero} {boleto.ApellidoPasajero}";
                            string infoOrden = $"- {nombreCompletoPasajero} (Tipo: {boleto.TipoDeBoleta}, Prioridad: {prioridadNumerica})";
                            ordenVisual.AppendLine(infoOrden);

                            if (!string.IsNullOrEmpty(boleto.IdPasajero))
                            {
                                Pasajero pasajeroAsociado = DatosGlobales.ListaGlobalDePasajeros.BuscarPasajeroPorId(boleto.IdPasajero);
                                if (pasajeroAsociado != null)
                                {
                                    _ordenDeAbordajeActual.Encolar(pasajeroAsociado, boleto);
                                }
                            }
                        }
                    }
                    else
                    {
                        
                        foreach (Boleto boleto in boletosOrdenados)
                        {
                            int prioridadNumerica = colaTemporalParaPrioridad.ObtenerPrioridadDesdeEnum(boleto.TipoDeBoleta);
                            string nombreCompletoPasajero = $"{boleto.NombrePasajero} {boleto.ApellidoPasajero}";
                            string infoOrden = $"- {nombreCompletoPasajero} (Tipo: {boleto.TipoDeBoleta}, Prioridad: {prioridadNumerica})";
                            ordenVisual.AppendLine(infoOrden);
                        }
                        MessageBox.Show("Advertencia: No se pudo acceder a la lista global de pasajeros. El orden de abordaje se muestra visualmente pero no se pudo construir la cola de prioridad con objetos Pasajero reales.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }


                    richTextBox1.Text = ordenVisual.ToString();

                    if (_ordenDeAbordajeActual.CantidadDePasajeros() > 0)
                    {
                        button1.Enabled = true; 
                    }
                    else
                    {
                        MessageBox.Show("No hay pasajeros registrados para este tren y estación con boletos válidos para abordar.", "Sin Pasajeros Pendientes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        button1.Enabled = false;
                    }

                }
                else
                {
                    richTextBox1.Text = "No se encontraron boletos registrados para esta estación y tren.";
                    button1.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Error interno: La lista global de boletos no está disponible para generar el orden de abordaje.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                button1.Enabled = false;
            }
        }

      
        private void button1_Click(object sender, EventArgs e)
        {
            if (_ordenDeAbordajeActual == null || _ordenDeAbordajeActual.CantidadDePasajeros() == 0)
            {
                MessageBox.Show("No hay un orden de abordaje generado para publicar.", "Nada que Publicar", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("Orden de abordaje publicado exitosamente (Lógica de almacenamiento pendiente).", "Publicación Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);

            
            button1.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Informacion_Trenes_Form13 formAnterior = new Informacion_Trenes_Form13();
            formAnterior.Show();
            this.Close();
        }

      
        private void label2_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { } 
        private void label3_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { } 
        private void label7_Click_1(object sender, EventArgs e) { }
        private void label6_Click_1(object sender, EventArgs e) { }
        private void richTextBox1_TextChanged(object sender, EventArgs e) { }
    }
}

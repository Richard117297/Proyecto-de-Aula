﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class Recomendacion_Rutas_Form8 : Form
    {
        public Recomendacion_Rutas_Form8()
        {
            InitializeComponent();
        }

        private void Recomendacion_Rutas_Form8_Load(object sender, EventArgs e)
        {
            CargarEstacionesEnDesplegables();


            comboBox3.Enabled = false; 
            textBox3.Enabled = false; 
            textBox1.Enabled = false;
            textBox5.Enabled = false; 
            button2.Enabled = false; 
            button1.Enabled = false; 

            textBox3.Text = "";
            textBox1.Text = "";
            textBox5.Text = "";


            comboBox1.Enabled = (comboBox1.Items.Count > 0);
            comboBox2.Enabled = (comboBox2.Items.Count > 0);
        }


        private void CargarEstacionesEnDesplegables()
        {
            comboBox1.Items.Clear(); 
            comboBox2.Items.Clear(); 


            if (DatosGlobales.ListaGlobalDeBoletos != null && DatosGlobales.ListaGlobalDeBoletos.Valor != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones != null)
            {
                foreach (var nodoEstacionGrafo in DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones)
                {
                    if (nodoEstacionGrafo != null && nodoEstacionGrafo.Estacion != null && nodoEstacionGrafo.Estacion.NombreEstacion != null && nodoEstacionGrafo.Estacion.NombreEstacion.Length > 0)
                    {
                        string nombreEstacion = nodoEstacionGrafo.Estacion.NombreEstacion[0];

                        comboBox1.Items.Add(nombreEstacion);
                        comboBox2.Items.Add(nombreEstacion);
                    }
                }

                comboBox1.Enabled = true;
                comboBox2.Enabled = true;
            }
            else
            {
                MessageBox.Show("Error interno: Datos globales o grafo no disponibles para cargar estaciones.", "Error de Carga", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox1.Enabled = false;
                comboBox2.Enabled = false;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            LimpiarCamposRutaRecomendada();
            VerificarHabilitarActualizar();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            LimpiarCamposRutaRecomendada();
            VerificarHabilitarActualizar();
        }


        private void LimpiarCamposRutaRecomendada()
        {
            comboBox3.Items.Clear(); 
            comboBox3.Enabled = false;
            textBox3.Text = ""; 
            textBox1.Text = "";
            textBox5.Text = ""; 
            button1.Enabled = false; 
        }


        private void VerificarHabilitarActualizar()
        {

            button2.Enabled = (comboBox1.SelectedItem != null && comboBox2.SelectedItem != null);
        }


        private void button2_Click(object sender, EventArgs e) 
        {

            if (comboBox1.SelectedItem == null || comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione la estación de partida y la estación de llegada.", "Seleccionar Estaciones", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            LimpiarCamposRutaRecomendada();


            if (DatosGlobales.ListaGlobalDeRutasRecomendadas == null || DatosGlobales.ListaGlobalDeBoletos?.Valor?.Estaciones == null)
            {
                MessageBox.Show("Error interno: Lista de rutas publicadas o estaciones no disponibles en Datos Globales.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                button2.Enabled = false; 
                return;
            }


            string nombreEstacionOrigen = comboBox1.SelectedItem.ToString();
            string nombreEstacionLlegada = comboBox2.SelectedItem.ToString();

            if (nombreEstacionOrigen == nombreEstacionLlegada)
            {
                MessageBox.Show("La estación de partida y la estación de llegada deben ser diferentes.", "Selección Inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<Ruta> rutasCoincidentes = new List<Ruta>();


            List<Ruta> rutasPublicadas = DatosGlobales.ListaGlobalDeRutasRecomendadas.GetAllRutas();



            if (rutasPublicadas != null)
            {

                foreach (Ruta ruta in rutasPublicadas)
                {

                    if (ruta != null && ruta.EstacionDePartida != null && ruta.EstacionDeLlegada != null &&
                        ruta.EstacionDePartida.NombreEstacion != null && ruta.EstacionDePartida.NombreEstacion.Length > 0 &&
                        ruta.EstacionDeLlegada.NombreEstacion != null && ruta.EstacionDeLlegada.NombreEstacion.Length > 0)
                    {

                        if (ruta.EstacionDePartida.NombreEstacion[0].Equals(nombreEstacionOrigen, StringComparison.OrdinalIgnoreCase) &&
                            ruta.EstacionDeLlegada.NombreEstacion[0].Equals(nombreEstacionLlegada, StringComparison.OrdinalIgnoreCase))
                        {
                            rutasCoincidentes.Add(ruta);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Error interno: No se pudo acceder a la lista de rutas publicadas.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; 
            }



            if (rutasCoincidentes.Count > 0)
            {
                comboBox3.Items.Clear(); 
                foreach (Ruta ruta in rutasCoincidentes)
                {
                    comboBox3.Items.Add(ruta); 
                }

                comboBox3.Enabled = true;


                if (comboBox3.Items.Count > 0)
                {
                    comboBox3.SelectedIndex = 0; 
                }
            }
            else
            {
                MessageBox.Show($"No se encontraron rutas publicadas directas de {nombreEstacionOrigen} a {nombreEstacionLlegada}.", "Rutas No Encontradas", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }



        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

            textBox3.Text = ""; 
            textBox1.Text = ""; 
            textBox5.Text = ""; 
            button1.Enabled = false; 


            if (comboBox3.SelectedItem is Ruta rutaSeleccionada)
            {

                textBox3.Text = rutaSeleccionada.DistanciaKm.ToString();
                textBox1.Text = rutaSeleccionada.FechaHoraDeSalida;
                textBox5.Text = rutaSeleccionada.IdRuta;


                button1.Enabled = true;
            }
            else
            {

                MessageBox.Show("Error interno al obtener la ruta seleccionada.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox3.Text = "";
                textBox1.Text = "";
                textBox5.Text = "";
                button1.Enabled = false;
            }
        }


        private void button1_Click(object sender, EventArgs e) 
        {

            if (comboBox3.SelectedItem == null || !(comboBox3.SelectedItem is Ruta rutaARecomendar))
            {
                MessageBox.Show("Por favor, seleccione una ruta para recomendar.", "Seleccionar Ruta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            if (DatosGlobales.ListaGlobalDeRutasRecomendadas != null)
            {

                DatosGlobales.ListaGlobalDeRutasRecomendadas.addRuta(rutaARecomendar); 


                MessageBox.Show($"Ruta '{rutaARecomendar.ToString()}' recomendada exitosamente para usuarios.", "Ruta Recomendada", MessageBoxButtons.OK, MessageBoxIcon.Information);


                LimpiarCamposRutaRecomendada(); 
                comboBox1.SelectedItem = null; 
                comboBox2.SelectedItem = null; 
                VerificarHabilitarActualizar(); 

            }
            else
            {
                MessageBox.Show("Error interno: La lista global de rutas recomendadas no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void button3_Click(object sender, EventArgs e) 
        {

            GestionRutas_Horarios_Form6 formAnterior = new GestionRutas_Horarios_Form6(); 
            formAnterior.Show();
            this.Close(); 
        }


    
        private void label3_Click(object sender, EventArgs e) { } 
        private void label1_Click(object sender, EventArgs e) { } 
        private void label2_Click(object sender, EventArgs e) { } 
        private void label4_Click(object sender, EventArgs e) { } 
        private void label5_Click(object sender, EventArgs e) { } 
        private void textBox3_TextChanged(object sender, EventArgs e) { } 
        private void label6_Click(object sender, EventArgs e) { } 
        private void label8_Click(object sender, EventArgs e) { } 
        private void textBox1_TextChanged(object sender, EventArgs e) { } 
        private void label7_Click(object sender, EventArgs e) { } 
        private void textBox5_TextChanged(object sender, EventArgs e) { }
    }
}

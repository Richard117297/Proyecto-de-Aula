﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class RegistrarInformacionBoleto_Form5 : Form
    {
        private string rutaArchivo = @"Base de datos JSON\Boleto.json";

        public RegistrarInformacionBoleto_Form5()
        {
            InitializeComponent();

        }

        private void RegistrarInformacionBoleto_Form5_Load(object sender, EventArgs e)
        {

            CargarBoletosPendientesDeRegistro();
        }


        private void CargarBoletosPendientesDeRegistro()
        {
            comboBox1.Items.Clear(); 
            richTextBox1.Clear();   


            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {

                List<Boleto> boletosPendientes = DatosGlobales.ListaGlobalDeBoletos.GetBoletosPendientesDeRegistro();


                if (boletosPendientes != null && boletosPendientes.Count > 0)
                {
                    foreach (Boleto boleto in boletosPendientes)
                    {

                        if (boleto != null && !string.IsNullOrEmpty(boleto.IdRegistro))
                        {
                            comboBox1.Items.Add(boleto.IdRegistro);
                        }
                    }

                }
                else
                {

                    MessageBox.Show("No hay boletos pendientes de registro en este momento.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {

                MessageBox.Show("Error interno: La lista global de boletos no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void button2_Click(object sender, EventArgs e) 
        {

            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un ID de boleto de la lista.", "Seleccionar Boleto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                richTextBox1.Clear();
                return;
            }

            string selectedId = comboBox1.SelectedItem.ToString();


            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {

                Boleto boletoEncontrado = DatosGlobales.ListaGlobalDeBoletos.BuscarBoletoPorId(selectedId); 

                if (boletoEncontrado != null)
                {

                    richTextBox1.Text = boletoEncontrado.GetInfoCompleta();
                }
                else
                {

                    MessageBox.Show($"Error interno: No se encontró el boleto con ID {selectedId} en la lista global.", "Error al Buscar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    richTextBox1.Clear();

                    CargarBoletosPendientesDeRegistro();
                }
            }
            else
            {

                MessageBox.Show("Error interno: La lista global de boletos no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                richTextBox1.Clear();
            }
        }


        private void button1_Click(object sender, EventArgs e) 
        {

            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un ID de boleto a registrar de la lista.", "Seleccionar Boleto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                richTextBox1.Clear();
                return;
            }

            string selectedId = comboBox1.SelectedItem.ToString();

            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {
                bool registradoExitoso = DatosGlobales.ListaGlobalDeBoletos.MarcarBoletoComoRegistrado(selectedId); 

                if (registradoExitoso)
                {
                    MessageBox.Show($"Boleto con ID {selectedId} registrado exitosamente.", "Registro Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    List<Boleto> boletosAGuardar = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();
                    Boleto.GuardarDatos(rutaArchivo, boletosAGuardar);
                    CargarBoletosPendientesDeRegistro();
                    richTextBox1.Clear(); 
                }
                else
                {
                  
                    MessageBox.Show($"Error al intentar registrar el boleto con ID {selectedId}.", "Error al Registrar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                   
                    CargarBoletosPendientesDeRegistro();
                    richTextBox1.Clear();
                }
            }
            else
            {
                
                MessageBox.Show("Error interno: La lista global de boletos no está disponible para registrar.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                richTextBox1.Clear();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            GestionTarifasYBoletos_Admin_Form3 formAnterior = new GestionTarifasYBoletos_Admin_Form3(); 
            formAnterior.Show();
            this.Close(); 
        }

      
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            richTextBox1.Clear();
            
             button2_Click(this, EventArgs.Empty);
        }

       
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void richTextBox1_TextChanged(object sender, EventArgs e) { }
    }
}

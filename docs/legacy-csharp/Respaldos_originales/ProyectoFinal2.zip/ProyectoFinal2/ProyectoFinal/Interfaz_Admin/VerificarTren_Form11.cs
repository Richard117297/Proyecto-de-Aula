﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Administrador
{
    public partial class VerificarTren_Form11 : Form
    {
        private string rutaArchivoTrenes = @"Base de datos JSON\Tren.json";
        public VerificarTren_Form11()
        {
            InitializeComponent();
        }

        private void VerificarTren_Form11_Load(object sender, EventArgs e)
        {

            CargarTrenesEnDesplegables();


            textBox3.Enabled = false;
            textBox3.Text = ""; 
            button2.Enabled = false; 
            button1.Enabled = false; 

            comboBox2.Enabled = (comboBox2.Items.Count > 0);
            comboBox1.Enabled = (comboBox1.Items.Count > 0);
        }


        private void CargarTrenesEnDesplegables()
        {
            comboBox2.Items.Clear(); 
            comboBox1.Items.Clear(); 


            if (DatosGlobales.ListaGlobalDeTrenes != null)
            {

                List<Tren> listaTrenes = DatosGlobales.ListaGlobalDeTrenes.GetAllTrenes(); 
                if (listaTrenes != null && listaTrenes.Count > 0)
                {

                    foreach (Tren tren in listaTrenes)
                    {

                        comboBox2.Items.Add(tren); 
                        comboBox1.Items.Add(tren); 
                    }

                    comboBox2.Enabled = true;
                    comboBox1.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay trenes agregados al sistema.", "Lista Vacía", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    comboBox2.Enabled = false;
                    comboBox1.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Error interno: La lista global de trenes no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox2.Enabled = false;
                comboBox1.Enabled = false;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e) 
        {

            textBox3.Text = "";
            button2.Enabled = (comboBox2.SelectedItem != null);
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) 
        {

            button1.Enabled = (comboBox1.SelectedItem != null);
        }


        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }


        private void label2_Click(object sender, EventArgs e) { }

        private void label1_Click(object sender, EventArgs e) { }

        private void label4_Click(object sender, EventArgs e) { }

        private void label5_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }

        private void label6_Click(object sender, EventArgs e) { }


        private void button2_Click(object sender, EventArgs e) 
        {

            if (comboBox2.SelectedItem == null || !(comboBox2.SelectedItem is Tren trenSeleccionado))
            {
                MessageBox.Show("Por favor, seleccione un tren en la lista superior para verificar su kilometraje.", "Seleccionar Tren", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox3.Text = ""; 
                return;
            }


            if (DatosGlobales.ListaGlobalDeBoletos?.Valor == null) 
            {
                MessageBox.Show("Error interno: Grafo de estaciones no disponible para calcular kilometraje.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox3.Text = "";
                return;
            }

            try
            {
                trenSeleccionado.calcularKilometrajeUsado(DatosGlobales.ListaGlobalDeBoletos.Valor);

                textBox3.Text = trenSeleccionado.Kilometraje.ToString("F2"); 
            }
            catch (Exception ex)
            {

                MessageBox.Show($"Error al verificar kilometraje: {ex.Message}", "Error de Cálculo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox3.Text = "Error"; 
            }
        }



        private void button1_Click(object sender, EventArgs e) 
        {

            if (comboBox1.SelectedItem == null || !(comboBox1.SelectedItem is Tren trenADarDeBaja))
            {
                MessageBox.Show("Por favor, seleccione un tren de la lista inferior para darlo de baja.", "Seleccionar Tren", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult resultado = MessageBox.Show($"¿Está seguro de que desea dar de baja el tren con ID '{trenADarDeBaja.IdTren}'?", "Confirmar Baja", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {

                if (DatosGlobales.ListaGlobalDeTrenes != null)
                {

                    DatosGlobales.ListaGlobalDeTrenes.DarDeBajaAlTren(trenADarDeBaja.IdTren);


                    try
                    {

                        List<Tren> trenesAGuardar = DatosGlobales.ListaGlobalDeTrenes.GetAllTrenes();


                        Tren.GuardarDatos(rutaArchivoTrenes, trenesAGuardar);

                        MessageBox.Show($"El tren con ID '{trenADarDeBaja.IdTren}' ha sido dado de baja exitosamente y los cambios guardados.", "Tren Dado de Baja", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        CargarTrenesEnDesplegables();

                        textBox3.Text = ""; 
                        button2.Enabled = false; 
                        button1.Enabled = false; 

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ocurrió un error al guardar los datos después de dar de baja el tren: {ex.Message}", "Error al Guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                else
                {
                    MessageBox.Show("Error interno: La lista global de trenes no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void button3_Click(object sender, EventArgs e) 
        {

            GestionTrenes_Form9 gestionTrenesForm = new GestionTrenes_Form9(); 
            gestionTrenesForm.Show(); 
            this.Close();
                          
        }
    }
}

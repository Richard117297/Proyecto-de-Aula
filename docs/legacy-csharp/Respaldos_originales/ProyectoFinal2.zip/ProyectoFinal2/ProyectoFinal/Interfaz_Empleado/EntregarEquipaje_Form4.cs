﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using Interfaz_Empleado;

namespace ProyectoFinal.Interfaz_Empleado
{
    public partial class EntregarEquipaje_Form4 : Form
    {
        private string rutaArchivoEquipajes = @"Base de datos JSON\Equipajes.json";

        public EntregarEquipaje_Form4()
        {
            InitializeComponent();
        }


        private void CargarEquipajesEnComboBox()
        {
            comboBox1.Items.Clear();

            if (DatosGlobales.ListaGlobalDeEquipajes == null || DatosGlobales.ListaGlobalDeEquipajes.ObtenerTodosEquipajes().Count == 0)
            {
                MessageBox.Show("No hay equipajes registrados en el sistema.", "Sin Equipajes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            foreach (var equipaje in DatosGlobales.ListaGlobalDeEquipajes.ObtenerTodosEquipajes())
            {
                comboBox1.Items.Add(equipaje.IdEquipaje);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void button1_Click(object sender, EventArgs e) 
        {
            string idEquipajeSeleccionado = comboBox1.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(idEquipajeSeleccionado))
            {
                MessageBox.Show("Seleccione un equipaje para buscar su información.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var equipajeSeleccionado = DatosGlobales.ListaGlobalDeEquipajes.BuscarEquipajePorId(idEquipajeSeleccionado);

            if (equipajeSeleccionado != null)
            {
                richTextBox1.Text = equipajeSeleccionado.GetInfoCompleta();
            }
            else
            {
                richTextBox1.Text = "No se encontró información del equipaje seleccionado.";
            }
        }

        private void button3_Click(object sender, EventArgs e) 
        {
            string idEquipajeSeleccionado = comboBox1.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(idEquipajeSeleccionado))
            {
                MessageBox.Show("Seleccione un equipaje para entregarlo.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var equipajeSeleccionado = DatosGlobales.ListaGlobalDeEquipajes.BuscarEquipajePorId(idEquipajeSeleccionado);

            if (equipajeSeleccionado != null)
            {
                DialogResult resultado = MessageBox.Show($"¿Está seguro de que desea entregar el equipaje con ID: {idEquipajeSeleccionado}?", "Confirmar Entrega", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    DatosGlobales.ListaGlobalDeEquipajes.EliminarEquipajePorId(idEquipajeSeleccionado);
                    GuardarEquipajesEnArchivo();

                    MessageBox.Show($"El equipaje con ID: {idEquipajeSeleccionado} ha sido entregado y eliminado del sistema.", "Entrega Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    CargarEquipajesEnComboBox();
                    richTextBox1.Clear();
                }
            }
            else
            {
                MessageBox.Show("No se encontró el equipaje seleccionado en el sistema.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GuardarEquipajesEnArchivo()
        {
            List<Equipaje> equipajesAGuardar = DatosGlobales.ListaGlobalDeEquipajes.ObtenerTodosEquipajes();
            Equipaje.GuardarDatos(rutaArchivoEquipajes, equipajesAGuardar);
        }

        private void button2_Click(object sender, EventArgs e) 
        {
            Main_Empleado_Form2 volverMain = new Main_Empleado_Form2();
            volverMain.Show();
            this.Close();
        }

        private void InformacionBoleto_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void EntregarEquipaje_Form4_Load_1(object sender, EventArgs e)
        {
            CargarEquipajesEnComboBox();
        }
    }
}

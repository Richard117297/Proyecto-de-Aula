﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Empleado
{
    public partial class IniciarSesion_Empleado_Form1 : Form
    {
        private Empleado empleado;

        public IniciarSesion_Empleado_Form1()
        {
            InitializeComponent();
            empleado = new Empleado("empleado", "empleadopass", "54321");
        }

        private void Iniciar_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Ingresar_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string usuario = textBox1.Text; 
            string contrasena = textBox2.Text;

            
            bool inicioSesionExitoso = empleado.IniciarSesion(usuario, contrasena);

            if (inicioSesionExitoso)
            {
                Main_Empleado_Form2 mainEmpleadoForm = new Main_Empleado_Form2();
                mainEmpleadoForm.Show();
                this.Hide(); 
            }
            else
            {
                MessageBox.Show("Inicio de sesión fallido. Usuario o contraseña incorrectos.", "Error de inicio de sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
           
                textBox1.Text = "";
                textBox2.Text = "";
                textBox1.Focus(); 
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 formInicio = new Form1();
            formInicio.Show();
            this.Close();
        }

        private void IniciarSesion_Empleado_Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

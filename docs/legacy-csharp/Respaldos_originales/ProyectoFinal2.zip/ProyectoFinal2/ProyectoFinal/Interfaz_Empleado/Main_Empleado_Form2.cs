﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;
using ProyectoFinal.Interfaz_Empleado;

namespace Interfaz_Empleado
{
    public partial class Main_Empleado_Form2 : Form
    {
        private string rutaArchivoBoletos = @"Base de datos JSON\Boleto.json";
        private string rutaArchivoEquipajes = @"Base de datos JSON\Equipajes.json";

        public Main_Empleado_Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Validacion_Boletos_Form3 formValidacion = new Validacion_Boletos_Form3();
            formValidacion.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 formInicio = new Form1();
            formInicio.Show();
            this.Close();
        }

        private void Main_Empleado_Form2_Load(object sender, EventArgs e)
        {
            // Cargar boletos desde el archivo JSON
            List<Boleto> boletosCargados = Boleto.CargarDatos(rutaArchivoBoletos);

            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {
                foreach (var boleto in boletosCargados)
                {
                    if (!DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos().Any(b => b.IdRegistro == boleto.IdRegistro))
                    {
                        DatosGlobales.ListaGlobalDeBoletos.AddBoleto(boleto);
                    }
                }
            }

            // Cargar equipajes desde el archivo JSON
            List<Equipaje> equipajesCargados = Equipaje.CargarDatos(rutaArchivoEquipajes);

            if (DatosGlobales.ListaGlobalDeEquipajes != null)
            {
                foreach (var equipaje in equipajesCargados)
                {
                    if (!DatosGlobales.ListaGlobalDeEquipajes.ObtenerTodosEquipajes().Any(equipajeExistente => equipajeExistente.IdEquipaje == equipaje.IdEquipaje))
                    {
                        DatosGlobales.ListaGlobalDeEquipajes.AgregarEquipaje(equipaje);
                    }
                }
            }

            MessageBox.Show("Datos de boletos y equipajes cargados correctamente.", "Carga Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EntregarEquipaje_Form4 formEntregar = new EntregarEquipaje_Form4();
            formEntregar.Show();
            this.Hide();
        }
    }
}

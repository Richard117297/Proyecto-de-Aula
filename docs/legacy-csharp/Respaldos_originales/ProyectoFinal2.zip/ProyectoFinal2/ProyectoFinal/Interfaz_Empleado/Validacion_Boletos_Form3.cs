﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Empleado
{
    public partial class Validacion_Boletos_Form3 : Form
    {
        private List<Boleto> boletosPendientesMostrados;
        private string rutaArchivo = @"Base de datos JSON\Boleto.json";

        public Validacion_Boletos_Form3()
        {
            InitializeComponent();
            boletosPendientesMostrados = new List<Boleto>();
        }

        private void Validacion_Boletos_Form3_Load(object sender, EventArgs e)
        {
            LimpiarCampos();
            HabilitarControlesIniciales();
            CargarBoletosPendientesEnDesplegable();
        }

        private void LimpiarCampos()
        {
            comboBox1.Items.Clear();
            comboBox1.SelectedIndex = -1;
            richTextBox1.Clear();
            boletosPendientesMostrados.Clear(); 
        }

        private void HabilitarControlesIniciales()
        {
            comboBox1.Enabled = true;
            button2.Enabled = false; 
            button1.Enabled = false;
            richTextBox1.Enabled = false; 
                                          
        }

        private void CargarBoletosPendientesEnDesplegable()
        {
            comboBox1.Items.Clear();
            boletosPendientesMostrados.Clear();

            if (DatosGlobales.ListaGlobalDeBoletos == null)
            {
                MessageBox.Show("Error interno: La lista global de boletos no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox1.Enabled = false;
                return;
            }

            List<Boleto> todosBoletos = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();
            if (todosBoletos != null)
            {
                boletosPendientesMostrados = todosBoletos.Where(b => !b.EsValidado && !b.EsRegistrado).ToList();

                if (boletosPendientesMostrados.Count > 0)
                {
                    foreach (Boleto boleto in boletosPendientesMostrados)
                    {

                        if (!string.IsNullOrEmpty(boleto.IdRegistro))
                        {
                            comboBox1.Items.Add(boleto.IdRegistro);
                        }

                    }
                    comboBox1.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay boletos pendientes de validación en este momento.", "Sin Boletos Pendientes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    comboBox1.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("No hay boletos disponibles en la lista global.", "Sin Datos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox1.Enabled = false;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            button1.Enabled = false; 
            button2.Enabled = false; 

            if (comboBox1.SelectedItem != null)
            {
                
                button1.Enabled = true; 
                button2.Enabled = true; 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un ID de registro de boleto.", "Seleccionar Boleto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string idRegistroSeleccionado = comboBox1.SelectedItem.ToString();


            Boleto boletoSeleccionado = boletosPendientesMostrados.FirstOrDefault(b => b.IdRegistro != null && b.IdRegistro.Equals(idRegistroSeleccionado, StringComparison.OrdinalIgnoreCase));


            if (boletoSeleccionado != null)
            {

                richTextBox1.Text = boletoSeleccionado.GetInfoCompleta(); 
                richTextBox1.Enabled = true; 
            }
            else
            {
                richTextBox1.Text = "No se encontró la información del boleto seleccionado.";
                richTextBox1.Enabled = false;

                button1.Enabled = false;
                button2.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un ID de registro de boleto para validar.", "Seleccionar Boleto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string idRegistroAValidar = comboBox1.SelectedItem.ToString();

            bool validacionExitosa = DatosGlobales.ListaGlobalDeBoletos.ValidarBoletoPorId(idRegistroAValidar);

            if (validacionExitosa)
            {
                MessageBox.Show($"Boleto con ID '{idRegistroAValidar}' validado exitosamente. Ahora está listo para ser registrado por el administrador.", "Validación Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);

                List<Boleto> boletosAGuardar = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();
                Boleto.GuardarDatos(rutaArchivo, boletosAGuardar);

                LimpiarCampos();
                HabilitarControlesIniciales();
                CargarBoletosPendientesEnDesplegable();
            }
            else
            {

                MessageBox.Show($"No se pudo validar el boleto con ID '{idRegistroAValidar}'. Es posible que ya haya sido validado o eliminado.", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LimpiarCampos();
                HabilitarControlesIniciales();
                CargarBoletosPendientesEnDesplegable();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Main_Empleado_Form2 formAnterior = new Main_Empleado_Form2();
            formAnterior.Show();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e) { } 
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void richTextBox1_TextChanged(object sender, EventArgs e) { }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Usuario
{
    public partial class Cambiar_Ruta_Form7 : Form
    {
        private Boleto boletoSeleccionado;

        public Cambiar_Ruta_Form7()
        {
            InitializeComponent();
        }

        private void Cambiar_Ruta_Form7_Load(object sender, EventArgs e)
        {
            CargarBoletosDisponibles(); 
            LimpiarCamposInformacion();
            DeshabilitarBotonesAccion();
        }

        private void CargarBoletosDisponibles() 
        {
            comboBox1.Items.Clear();
            comboBox1.SelectedIndex = -1;
            boletoSeleccionado = null;
            LimpiarCamposInformacion();

            if (DatosGlobales.ListaGlobalDeBoletos == null || DatosGlobales.ListaGlobalDeBoletos.Cabeza == null)
            {
                MessageBox.Show("No hay boletos registrados en el sistema.", "Sin Boletos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox1.Enabled = false;
                DeshabilitarBotonesAccion();
                return;
            }

            List<Boleto> todosLosBoletos = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();


            if (todosLosBoletos.Count > 0)
            {
                foreach (Boleto boleto in todosLosBoletos)
                {

                    if (!string.IsNullOrEmpty(boleto.IdRegistro))
                    {
                        comboBox1.Items.Add(boleto.IdRegistro);
                    }
                }
                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.Enabled = true;

                }
                else
                {
                    MessageBox.Show("Se encontraron boletos, pero no tienen un ID de registro válido.", "Error de Datos de Boleto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBox1.Enabled = false;
                }

            }
            else
            {
                MessageBox.Show("No hay boletos registrados en el sistema.", "Sin Boletos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox1.Enabled = false;
            }
            DeshabilitarBotonesAccion();
        }

        private void LimpiarCamposInformacion()
        {
            textBox1.Clear(); 
            textBox3.Clear(); 
            textBox5.Clear(); 
            textBox7.Clear(); 
        }

        private void DeshabilitarBotonesAccion()
        {
            button1.Enabled = false;
            button3.Enabled = false; 
        }

        private void HabilitarBotonesAccion()
        {
            button1.Enabled = true; 
            button3.Enabled = true;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string idRegistroSeleccionado = comboBox1.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(idRegistroSeleccionado))
            {

                boletoSeleccionado = DatosGlobales.ListaGlobalDeBoletos.BuscarBoletoPorId(idRegistroSeleccionado);


                if (boletoSeleccionado != null)
                {
                    LimpiarCamposInformacion();
                    HabilitarBotonesAccion();

                }
                else
                {
                    boletoSeleccionado = null;
                    LimpiarCamposInformacion();
                    DeshabilitarBotonesAccion();
                    MessageBox.Show($"No se encontró el boleto con ID de registro '{idRegistroSeleccionado}'.", "Error de Búsqueda", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                boletoSeleccionado = null;
                LimpiarCamposInformacion();
                DeshabilitarBotonesAccion();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (boletoSeleccionado != null)
            {

                textBox1.Text = boletoSeleccionado.NombrePasajero;
                textBox3.Text = boletoSeleccionado.ApellidoPasajero;
                textBox5.Text = boletoSeleccionado.TipoIdentificacion; 
                textBox7.Text = boletoSeleccionado.NumeroTelefono.ToString(); 
            }
            else
            {
                MessageBox.Show("Seleccione un boleto para mostrar la información.", "Sin Boleto Seleccionado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (boletoSeleccionado == null)
            {
                MessageBox.Show("Seleccione un boleto para cambiar la ruta.", "Sin Boleto Seleccionado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (boletoSeleccionado.EsValidado || boletoSeleccionado.EsRegistrado)
            {
                MessageBox.Show("No se puede cambiar la ruta de un boleto ya validado o registrado.", "Cambio No Permitido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Modulo_RutaForm8 formCambioRuta = new Modulo_RutaForm8(this.boletoSeleccionado);
            formCambioRuta.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main_Usuario_Form2 main_Usuario_Form2 = new Main_Usuario_Form2();
            main_Usuario_Form2.Show();
            this.Close();
        }


        private void textBox7_TextChanged(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label8_Click_1(object sender, EventArgs e) { }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Usuario
{
    public partial class ComfimarCompra_Form6 : Form
    {
        private Boleto boletoFinal;
        private string rutaArchivo = @"Base de datos JSON\Boleto.json";

        public ComfimarCompra_Form6(Boleto boleto)
        {
            InitializeComponent();
            this.boletoFinal = boleto;
            MostrarInformacionCompra();
        }

        public ComfimarCompra_Form6()
        {
            InitializeComponent();
            this.boletoFinal = null;
            MessageBox.Show("Este formulario no debe abrirse directamente sin la información de la compra.", "Error de Navegación", MessageBoxButtons.OK, MessageBoxIcon.Error);
            LimpiarCamposInfoCompra();
            DeshabilitarBotonesAccion();
        }

        private void ComfimarCompra_Form6_Load(object sender, EventArgs e)
        {

        }

        private void MostrarInformacionCompra()
        {
            if (this.boletoFinal != null)
            {
                textBox1.Text = $"{boletoFinal.NombrePasajero} {boletoFinal.ApellidoPasajero}";
                textBox2.Text = boletoFinal.TipoIdentificacion;


                textBox3.Text = $"{boletoFinal.PesoEquipaje} kg";
                textBox4.Text = boletoFinal.IdEquipaje ?? "Sin Equipaje";


                textBox5.Text = $"{boletoFinal.IdTren} ({boletoFinal.EstacionOrigen} a {boletoFinal.EstacionFinal})";



                HabilitarBotonesAccion();
            }
            else
            {
                LimpiarCamposInfoCompra();
                DeshabilitarBotonesAccion();
            }
        }

        private void LimpiarCamposInfoCompra()
        {
            
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();

        }

        private void HabilitarBotonesAccion()
        {

            button1.Enabled = true;
            button2.Enabled = true; 
        }

        private void DeshabilitarBotonesAccion()
        {

            button1.Enabled = false;
            button2.Enabled = false;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (this.boletoFinal == null)
            {
                MessageBox.Show("No hay información de boleto para confirmar la compra.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {
                DatosGlobales.ListaGlobalDeBoletos.AddBoleto(this.boletoFinal);
            }
            else
            {
                MessageBox.Show("Error interno: No se pudo acceder a la lista global de boletos.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

          
            List<Boleto> boletosAGuardar = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();
            Boleto.GuardarDatos(rutaArchivo, boletosAGuardar);

          
            MessageBox.Show($"Compra del boleto {this.boletoFinal.IdRegistro} confirmada. Su boleto está listo para ser validado por un empleado.", "Pago Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);

           
            Main_Usuario_Form2 formMenuUsuario = new Main_Usuario_Form2();
            formMenuUsuario.Show();
            this.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main_Usuario_Form2 formMenuUsuario = new Main_Usuario_Form2();
            formMenuUsuario.Show();
            this.Close();
        }


        private void label3_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
    }
}

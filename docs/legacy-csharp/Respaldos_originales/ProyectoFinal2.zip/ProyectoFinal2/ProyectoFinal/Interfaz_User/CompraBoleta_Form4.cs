﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;
using ProyectoFinal.Codigo_Proyecto.gestion_de_boletos;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Interfaz_Usuario
{
    public partial class CompraBoleta_Form4 : Form
    {
        public CompraBoleta_Form4()
        {
            InitializeComponent();
        }

        private void CompraBoleta_Form4_Load(object sender, EventArgs e)
        {
            LimpiarCampos(); 
            DeshabilitarControlesIniciales(); 
            CargarEstacionesEnDesplegables(); 
            CargarTiposBoletoEnDesplegable(); 
        }

        private void LimpiarCampos()
        {
            comboBox1.SelectedIndex = -1; 
            comboBox2.SelectedIndex = -1; 
            textBox3.Clear(); 
            textBox1.Clear(); 
            comboBox3.Items.Clear();
            comboBox3.SelectedIndex = -1;
            textBox5.Clear(); 
            comboBox4.SelectedIndex = -1; 

            LimpiarCamposDependientesEstacion(); 
        }

        private void DeshabilitarControlesIniciales()
        {
            textBox3.Enabled = true; 
            textBox1.Enabled = false; 
            comboBox3.Enabled = false; 
            button3.Enabled = false; 
            textBox5.Enabled = false; 
            button1.Enabled = false; 
            button2.Enabled = true; 
            comboBox4.Enabled = true;
        }

        private void CargarEstacionesEnDesplegables()
        {
            comboBox1.Items.Clear(); 
            comboBox2.Items.Clear(); 
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;

            if (DatosGlobales.ListaGlobalDeBoletos != null && DatosGlobales.ListaGlobalDeBoletos.Valor != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones != null)
            {
                foreach (var nodoEstacionGrafo in DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones)
                {
                    if (nodoEstacionGrafo != null && nodoEstacionGrafo.Estacion != null && nodoEstacionGrafo.Estacion.NombreEstacion != null && nodoEstacionGrafo.Estacion.NombreEstacion.Length > 0)
                    {
                        string nombreEstacion = nodoEstacionGrafo.Estacion.NombreEstacion[0]; 

                        comboBox1.Items.Add(nombreEstacion);
                        comboBox2.Items.Add(nombreEstacion);
                    }
                }
                comboBox1.Enabled = (comboBox1.Items.Count > 0);
                comboBox2.Enabled = (comboBox2.Items.Count > 0);

            }
            else
            {
                MessageBox.Show("Error interno: Datos globales o grafo de estaciones no disponibles para cargar estaciones.", "Error de Carga", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox1.Enabled = false;
                comboBox2.Enabled = false;
            }
        }

        private void CargarTiposBoletoEnDesplegable()
        {
            comboBox4.Items.Clear();
            comboBox4.SelectedIndex = -1;

            string[] tiposBoleto = Enum.GetNames(typeof(TipoBoletoEnum));
            foreach (string tipo in tiposBoleto)
            {
                if (tipo != TipoBoletoEnum.Desconocido.ToString()) 
                {
                    comboBox4.Items.Add(tipo);
                }
            }
            comboBox4.Enabled = (comboBox4.Items.Count > 0);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LimpiarCamposDependientesEstacion(); 
            EvaluarHabilitacionCalcularPrecio(); 
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            LimpiarCamposDependientesEstacion(); 
            EvaluarHabilitacionCalcularPrecio(); 
        }

        private void comboBox4_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            EvaluarHabilitacionCalcularPrecio();
                                               
        }


        private void LimpiarCamposDependientesEstacion()
        {
            textBox1.Clear(); 
            comboBox3.Items.Clear(); 
            comboBox3.SelectedIndex = -1;
            comboBox3.Enabled = false;
            textBox5.Clear(); 
            button1.Enabled = false; 
            CargarTrenesDisponibles(); 
        }


        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            EvaluarHabilitacionCalcularPrecio(); 
        }

        private void comboBox3_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            EvaluarHabilitacionCalcularPrecio(); 
        }

        private void EvaluarHabilitacionCalcularPrecio()
        {
            button3.Enabled = (comboBox1.SelectedItem != null &&
                               comboBox2.SelectedItem != null &&
                               !string.IsNullOrEmpty(textBox3.Text) &&
                               comboBox4.SelectedItem != null && 
                               comboBox3.SelectedItem != null);
        }

        private void CargarTrenesDisponibles()
        {
            comboBox3.Items.Clear(); 
            comboBox3.SelectedIndex = -1;
            comboBox3.Enabled = false; 

            string estacionPartida = comboBox1.SelectedItem?.ToString();
            string estacionLlegada = comboBox2.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(estacionPartida) || string.IsNullOrEmpty(estacionLlegada) || DatosGlobales.ListaGlobalDeTrenes == null || DatosGlobales.ListaGlobalDeTrenes.Cabeza == null)
            {
                return; 
            }

            List<Tren> trenesDisponibles = DatosGlobales.ListaGlobalDeTrenes.GetAllTrenes()
                .Where(t => t.RutaAsignada != null &&
                             t.RutaAsignada.EstacionDePartida != null &&
                             t.RutaAsignada.EstacionDePartida.NombreEstacion != null &&
                             t.RutaAsignada.EstacionDePartida.NombreEstacion.Length > 0 &&
                             t.RutaAsignada.EstacionDePartida.NombreEstacion[0].Equals(estacionPartida, StringComparison.OrdinalIgnoreCase) &&
                             t.RutaAsignada.EstacionDeLlegada != null &&
                             t.RutaAsignada.EstacionDeLlegada.NombreEstacion != null &&
                             t.RutaAsignada.EstacionDeLlegada.NombreEstacion.Length > 0 &&
                             t.RutaAsignada.EstacionDeLlegada.NombreEstacion[0].Equals(estacionLlegada, StringComparison.OrdinalIgnoreCase))
                .ToList();


            if (trenesDisponibles.Count > 0)
            {
                foreach (Tren tren in trenesDisponibles)
                {
                    comboBox3.Items.Add(tren.IdTren);
                }
                comboBox3.Enabled = true;
            }
            else
            {
                MessageBox.Show($"No hay trenes disponibles con una ruta asignada exactamente de '{estacionPartida}' a '{estacionLlegada}'.", "Sin Trenes Disponibles", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox3.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string estacionPartida = comboBox1.SelectedItem?.ToString();
            string estacionLlegada = comboBox2.SelectedItem?.ToString();
            string horarioTexto = textBox3.Text.Trim();
            string tipoBoletoSeleccionadoTexto = comboBox4.SelectedItem?.ToString(); 
            string idTrenSeleccionado = comboBox3.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(estacionPartida) || string.IsNullOrEmpty(estacionLlegada) || string.IsNullOrEmpty(horarioTexto) || string.IsNullOrEmpty(tipoBoletoSeleccionadoTexto) || string.IsNullOrEmpty(idTrenSeleccionado))
            {
                MessageBox.Show("Por favor, complete todos los campos (Estación Partida, Estación Llegada, Hora de salida, Tipo de boleto, Tren) antes de calcular el precio.", "Campos Incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Clear();
                textBox1.Clear();
                button1.Enabled = false;
                return;
            }

            TipoBoletoEnum tipoBoleto;
            if (!Enum.TryParse(tipoBoletoSeleccionadoTexto, true, out tipoBoleto) || tipoBoleto == TipoBoletoEnum.Desconocido)
            {
                MessageBox.Show("Selección de tipo de boleto no válida. Error interno.", "Error de Selección", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox5.Clear();
                textBox1.Clear();
                button1.Enabled = false;
                return;
            }

            Tren trenSeleccionado = DatosGlobales.ListaGlobalDeTrenes.BuscarTrenPorId(idTrenSeleccionado);

            if (trenSeleccionado == null || trenSeleccionado.RutaAsignada == null)
            {
                MessageBox.Show($"Error: Información de ruta no disponible para el tren seleccionado '{idTrenSeleccionado}'. Contacte al administrador.", "Error Interno", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox5.Clear();
                textBox1.Clear();
                button1.Enabled = false;
                return;
            }

            bool rutaCoincide = trenSeleccionado.RutaAsignada.EstacionDePartida != null &&
                                 trenSeleccionado.RutaAsignada.EstacionDePartida.NombreEstacion != null &&
                                 trenSeleccionado.RutaAsignada.EstacionDePartida.NombreEstacion.Length > 0 &&
                                 trenSeleccionado.RutaAsignada.EstacionDePartida.NombreEstacion[0].Equals(estacionPartida, StringComparison.OrdinalIgnoreCase) &&
                                 trenSeleccionado.RutaAsignada.EstacionDeLlegada != null &&
                                 trenSeleccionado.RutaAsignada.EstacionDeLlegada.NombreEstacion != null &&
                                 trenSeleccionado.RutaAsignada.EstacionDeLlegada.NombreEstacion.Length > 0 &&
                                 trenSeleccionado.RutaAsignada.EstacionDeLlegada.NombreEstacion[0].Equals(estacionLlegada, StringComparison.OrdinalIgnoreCase);


            if (!rutaCoincide)
            {
                MessageBox.Show($"El tren '{idTrenSeleccionado}' no tiene asignada la ruta exacta de '{estacionPartida}' a '{estacionLlegada}'. Por favor, seleccione un tren diferente o verifique las estaciones.", "Tren Incorrecto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Clear();
                textBox1.Clear();
                button1.Enabled = false;
                return;
            }

            Estacion objEstacionPartida = DatosGlobales.ListaGlobalDeBoletos.Valor.BuscarEstacionPorNombre(estacionPartida);
            Estacion objEstacionLlegada = DatosGlobales.ListaGlobalDeBoletos.Valor.BuscarEstacionPorNombre(estacionLlegada);

            if (objEstacionPartida == null || objEstacionLlegada == null)
            {
                MessageBox.Show("Error interno al encontrar los objetos Estación para calcular la distancia.", "Error de Estaciones", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox5.Clear();
                textBox1.Clear();
                button1.Enabled = false;
                return;
            }

            int indexPartida = DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones.FindIndex(n => n.Estacion != null && n.Estacion.NombreEstacion != null && n.Estacion.NombreEstacion.Length > 0 && n.Estacion.NombreEstacion[0].Equals(estacionPartida, StringComparison.OrdinalIgnoreCase));
            int indexLlegada = DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones.FindIndex(n => n.Estacion != null && n.Estacion.NombreEstacion != null && n.Estacion.NombreEstacion.Length > 0 && n.Estacion.NombreEstacion[0].Equals(estacionLlegada, StringComparison.OrdinalIgnoreCase));


            if (indexPartida == -1 || indexLlegada == -1)
            {
                MessageBox.Show("Error interno: No se pudieron encontrar los índices de las estaciones seleccionadas en el grafo.", "Error de Índices", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox5.Clear();
                textBox1.Clear();
                button1.Enabled = false;
                return;
            }

            int distancia = DatosGlobales.ListaGlobalDeBoletos.Valor.CalcularDistancia(indexPartida, indexLlegada);

            if (distancia == int.MaxValue)
            {
                MessageBox.Show($"No hay una ruta directa definida en el grafo entre '{estacionPartida}' y '{estacionLlegada}'. Por favor, seleccione otras estaciones.", "Ruta No Conectada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Clear();
                textBox1.Clear();
                button1.Enabled = false;
                return;
            }

            string claveRutaPrecio = $"{estacionPartida}-{estacionLlegada}";
            double precioBasePorKm = 0;

            if (DatosGlobales.PreciosRutaPorKilometro != null && DatosGlobales.PreciosRutaPorKilometro.ContainsKey(claveRutaPrecio))
            {
                precioBasePorKm = DatosGlobales.PreciosRutaPorKilometro[claveRutaPrecio];
            }
            else
            {
                MessageBox.Show($"No se ha definido un precio por kilómetro para la ruta '{estacionPartida}-{estacionLlegada}'. Contacte al administrador para configurarlo.", "Precio No Definido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Clear();
                textBox1.Clear();
                button1.Enabled = false;
                return;
            }

            double precioCalculado = precioBasePorKm * distancia;

            double factorPrecio = 1.0;
            switch (tipoBoleto)
            {
                case TipoBoletoEnum.Premium:
                    factorPrecio = 1.5;
                    break;
                case TipoBoletoEnum.Ejecutivo:
                    factorPrecio = 1.2; 
                    break;
                case TipoBoletoEnum.Estandar:
                    factorPrecio = 1.0; 
                    break;
            }

            precioCalculado *= factorPrecio;

            textBox5.Text = precioCalculado.ToString("N2") + " COP";

            textBox1.Text = $"{estacionPartida} a {estacionLlegada} (Tren: {idTrenSeleccionado})";

            button1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string estacionPartida = comboBox1.SelectedItem?.ToString();
            string estacionLlegada = comboBox2.SelectedItem?.ToString();
            string horarioSalida = textBox3.Text.Trim();
            string tipoBoletoSeleccionadoTexto = comboBox4.SelectedItem?.ToString(); 
            string idTren = comboBox3.SelectedItem?.ToString();
            double precio = 0;
            string precioTextoLimpio = textBox5.Text.Replace("$", "").Replace(",", "").Replace(" COP", "").Trim();

            if (!double.TryParse(precioTextoLimpio, out precio))
            {
                MessageBox.Show("Error interno al obtener el precio calculado para transferir.", "Error de Precio", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; 
            }

            string rutaPreseleccionadaTexto = textBox1.Text.Trim();

            TipoBoletoEnum tipoBoleto;
            if (!Enum.TryParse(tipoBoletoSeleccionadoTexto, true, out tipoBoleto) || tipoBoleto == TipoBoletoEnum.Desconocido)
            {
                MessageBox.Show("Error interno: Tipo de boleto no válido al preparar datos para siguiente paso.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; 
            }

            DatosCompraBoleto datosParaTransferir = new DatosCompraBoleto
            {
                EstacionPartida = estacionPartida,
                EstacionLlegada = estacionLlegada,
                HorarioSalida = horarioSalida,
                TipoBoleto = tipoBoleto, 
                IdTrenSeleccionado = idTren,
                PrecioCalculado = precio,
                RutaPreseleccionadaTexto = rutaPreseleccionadaTexto,
                IdUsuarioLoggeado = null 
            };

            DigitarInfo_Boleto_Form5 formDigitarInfo = new DigitarInfo_Boleto_Form5(datosParaTransferir);
            formDigitarInfo.Show();
            this.Hide(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main_Usuario_Form2 formAnterior = new Main_Usuario_Form2();
            formAnterior.Show();
            this.Close(); 
        }
        private void label1_Click(object sender, EventArgs e) { } 
        private void label5_Click(object sender, EventArgs e) { } 
        private void textBox1_TextChanged_1(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { } 
        private void label7_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { } 
        private void label4_Click(object sender, EventArgs e) { } 
        private void label6_Click(object sender, EventArgs e) { } 
        private void label2_Click(object sender, EventArgs e) { } 
        private void label8_Click(object sender, EventArgs e) { } 
        private void label9_Click(object sender, EventArgs e) { } 

    }
}

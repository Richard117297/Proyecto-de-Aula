﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;
using ProyectoFinal.Codigo_Proyecto.gestion_de_boletos;
using ProyectoFinal.Interfaz_User;

namespace Interfaz_Usuario
{
    public partial class DigitarInfo_Boleto_Form5 : Form
    {
        private DatosCompraBoleto datosCompra;
        private Random random;

        private const int PesoMaximoMaleta = 80;
        private const int MaxMaletasPorPasajero = 2;


        public DigitarInfo_Boleto_Form5(DatosCompraBoleto datosCompra)
        {
            InitializeComponent();
            this.datosCompra = datosCompra;
            this.random = new Random();
        }

        public DigitarInfo_Boleto_Form5()
        {
            InitializeComponent();
            this.datosCompra = null;
            this.random = new Random();
        }

        private void DigitarInfo_Boleto_Form5_Load(object sender, EventArgs e)
        {
            if (this.datosCompra == null)
            {
                MessageBox.Show("Error: No se recibieron los datos de la compra. Regrese al formulario anterior.", "Error de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                HabilitarCamposEntradaUsuario(false);
                DeshabilitarCamposInfoBoletoMostrada();
                button1.Enabled = false;
            }
            else
            {
                HabilitarCamposEntradaUsuario(true);
                button1.Enabled = true; 
                DeshabilitarCamposInfoBoletoMostrada(); 
                MostrarInfoBoletoRecibida(); 
            }
        }

        private void HabilitarCamposEntradaUsuario(bool enabled)
        {

            textBox1.Enabled = enabled; 
            textBox3.Enabled = enabled; 
            textBox5.Enabled = enabled; 
            textBox7.Enabled = enabled; 
            textBox2.Enabled = enabled; 
            textBox4.Enabled = enabled; 
            textBox6.Enabled = enabled; 
            textBox8.Enabled = enabled; 
            textBox12.Enabled = enabled; 

            button2.Enabled = true; 
        }

        private void DeshabilitarCamposInfoBoletoMostrada()
        {
            textBox9.Enabled = false; 
            textBox10.Enabled = false; 
            textBox11.Enabled = false; 
        }

        private void MostrarInfoBoletoRecibida()
        {
            if (this.datosCompra != null)
            {
                textBox9.Text = this.datosCompra.TipoBoleto.ToString();
                textBox10.Text = this.datosCompra.EstacionPartida;
                textBox11.Text = this.datosCompra.EstacionLlegada;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.datosCompra == null)
            {
                MessageBox.Show("No se han cargado los datos de la compra. Regrese al formulario anterior.", "Error de Datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string nombrePasajero = textBox1.Text.Trim();
            string apellidoPasajero = textBox3.Text.Trim();
            string tipoIdentificacion = textBox5.Text.Trim();
            string numeroTelefono = textBox7.Text.Trim();
            string nombreContacto = textBox2.Text.Trim();
            string apellidoContacto = textBox4.Text.Trim();
            string telefonoContacto = textBox6.Text.Trim();
            string pesoEquipajeTexto = textBox8.Text.Trim();
            string cantidadEquipajeTexto = textBox12.Text.Trim(); 

            if (string.IsNullOrEmpty(nombrePasajero) || string.IsNullOrEmpty(apellidoPasajero) || string.IsNullOrEmpty(tipoIdentificacion) || string.IsNullOrEmpty(numeroTelefono))
            {
                MessageBox.Show("Por favor, complete la información personal del pasajero (Nombre, Apellido, Tipo Identificación, Teléfono).", "Campos Incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int pesoEquipaje = 0;
            int cantidadEquipaje = 0;

            if (string.IsNullOrEmpty(pesoEquipajeTexto))
            {
                pesoEquipaje = 0;
            }
            else
            {
                if (!int.TryParse(pesoEquipajeTexto, out pesoEquipaje))
                {
                    MessageBox.Show("Por favor, ingrese un valor numérico válido para el peso del equipaje.", "Entrada Inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox8.Focus(); 
                    return;
                }

                if (pesoEquipaje > 0 && (pesoEquipaje < 1 || pesoEquipaje > PesoMaximoMaleta))
                {
                    MessageBox.Show($"El peso del equipaje debe estar entre 1 y {PesoMaximoMaleta} kg por maleta, si lleva equipaje.", "Validación de Equipaje", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox8.Focus(); 
                    return;
                }
            }


            if (string.IsNullOrEmpty(cantidadEquipajeTexto))
            {
                cantidadEquipaje = 0;
            }
            else
            {
                if (!int.TryParse(cantidadEquipajeTexto, out cantidadEquipaje))
                {
                    MessageBox.Show("Por favor, ingrese un valor numérico válido para la cantidad de equipaje.", "Entrada Inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox12.Focus();
                    return;
                }

                if (cantidadEquipaje > 0 && (cantidadEquipaje < 1 || cantidadEquipaje > MaxMaletasPorPasajero))
                {
                    MessageBox.Show($"La cantidad de equipaje debe estar entre 1 y {MaxMaletasPorPasajero} maletas por pasajero, si lleva equipaje.", "Validación de Equipaje", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox12.Focus(); 
                    return;
                }
            }

            if ((cantidadEquipaje > 0 && pesoEquipaje <= 0) || (cantidadEquipaje <= 0 && pesoEquipaje > 0))
            {
                MessageBox.Show("Por favor, ingrese una cantidad de equipaje y un peso consistentes (si lleva equipaje, ingrese cantidad y peso; si no, deje ambos en blanco o 0).", "Validación de Equipaje", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                if (cantidadEquipaje > 0) textBox8.Focus(); else textBox12.Focus();
                return;
            }

            Boleto nuevoBoleto = new Boleto();

            nuevoBoleto.EstacionOrigen = this.datosCompra.EstacionPartida;
            nuevoBoleto.EstacionFinal = this.datosCompra.EstacionLlegada;
            nuevoBoleto.FechaHoraSalida = this.datosCompra.HorarioSalida;
            nuevoBoleto.TipoDeBoleta = this.datosCompra.TipoBoleto;
            nuevoBoleto.IdTren = this.datosCompra.IdTrenSeleccionado;
            nuevoBoleto.ValorPasaje = this.datosCompra.PrecioCalculado;
            nuevoBoleto.NombrePasajero = nombrePasajero;
            nuevoBoleto.ApellidoPasajero = apellidoPasajero;
            nuevoBoleto.TipoIdentificacion = tipoIdentificacion;
            nuevoBoleto.NumeroTelefono = numeroTelefono;
            nuevoBoleto.NombreContacto = nombreContacto;
            nuevoBoleto.ApellidoContacto = apellidoContacto;
            nuevoBoleto.TelefonoContacto = telefonoContacto;
            nuevoBoleto.PesoEquipaje = pesoEquipaje; 
            nuevoBoleto.CantidadEquipaje = cantidadEquipaje; 

            if (cantidadEquipaje > 0 && pesoEquipaje > 0)
            {
                nuevoBoleto.IdEquipaje = "EQP-" + Guid.NewGuid().ToString().Substring(0, 8).ToUpper();
            }
            else
            {
                nuevoBoleto.IdEquipaje = null; 
            }

            nuevoBoleto.FechaHoraCompra = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            nuevoBoleto.FechaHoraLlegada = "Pendiente de cálculo"; 

            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {

                DatosGlobales.ListaGlobalDeBoletos.AddBoleto(nuevoBoleto);


            }
            else
            {
                MessageBox.Show("Error interno: No se pudo acceder a la lista global de boletos para guardar la compra.", "Error al Guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Seleccion_Asiento_Form5_5 formSeleccionAsiento = new Seleccion_Asiento_Form5_5(nuevoBoleto);
            formSeleccionAsiento.Show();
            this.Hide(); 
        }


        private void button2_Click(object sender, EventArgs e)
        {

            CompraBoleta_Form4 formAnterior = new CompraBoleta_Form4();
            formAnterior.Show();
            this.Close(); 
        }



        private void label1_Click(object sender, EventArgs e) { } 
        private void label5_Click(object sender, EventArgs e) { } 
        private void textBox1_TextChanged(object sender, EventArgs e) { } 
        private void label4_Click(object sender, EventArgs e) { } 
        private void textBox3_TextChanged(object sender, EventArgs e) { } 
        private void label6_Click(object sender, EventArgs e) { } 
        private void textBox7_TextChanged(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { } 
        private void textBox10_TextChanged(object sender, EventArgs e) { } 
        private void label8_Click(object sender, EventArgs e) { } 
        private void textBox11_TextChanged(object sender, EventArgs e) { } 
        private void label9_Click(object sender, EventArgs e) { } 
        private void textBox2_TextChanged(object sender, EventArgs e) { } 
        private void label10_Click(object sender, EventArgs e) { } 
        private void textBox4_TextChanged(object sender, EventArgs e) { } 
        private void label11_Click(object sender, EventArgs e) { } 
        private void textBox6_TextChanged(object sender, EventArgs e) { } 
        private void label12_Click(object sender, EventArgs e) { } 
        private void textBox8_TextChanged(object sender, EventArgs e) { } 
        private void label13_Click(object sender, EventArgs e) { } 
        private void textBox9_TextChanged(object sender, EventArgs e) { } 
        private void textBox5_TextChanged(object sender, EventArgs e) { } 
        private void label2_Click(object sender, EventArgs e) { } 
        private void label3_Click(object sender, EventArgs e) { }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

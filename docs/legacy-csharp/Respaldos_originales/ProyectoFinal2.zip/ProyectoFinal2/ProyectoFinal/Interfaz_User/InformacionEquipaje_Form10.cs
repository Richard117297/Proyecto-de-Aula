﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using Interfaz_Usuario;

namespace ProyectoFinal.Interfaz_User
{
    public partial class InformacionEquipaje_Form10 : Form
    {
        private string rutaArchivoEquipajes = @"Base de datos JSON\Equipajes.json";
        private string rutaArchivoBoletos = @"Base de datos JSON\Boleto.json";

        public InformacionEquipaje_Form10()
        {
            InitializeComponent();
        }

        private void InformacionEquipaje_Form10_Load(object sender, EventArgs e)
        {
            CargarBoletosDesdeArchivo();
            CargarBoletosEnComboBox();
        }

        private void CargarBoletosDesdeArchivo()
        {
            List<Boleto> boletosCargados = Boleto.CargarDatos(rutaArchivoBoletos);
            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {
                foreach (var boleto in boletosCargados)
                {
                    if (!DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos().Any(b => b.IdRegistro == boleto.IdRegistro))
                    {
                        DatosGlobales.ListaGlobalDeBoletos.AddBoleto(boleto);
                    }
                }
            }
        }

        private void CargarBoletosEnComboBox()
        {
            comboBox1.Items.Clear();

            if (DatosGlobales.ListaGlobalDeBoletos == null || DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos().Count == 0)
            {
                MessageBox.Show("No hay boletos registrados en el sistema.", "Sin Boletos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            foreach (var boleto in DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos())
            {
                comboBox1.Items.Add(boleto.IdRegistro);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string idBoletoSeleccionado = comboBox1.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(idBoletoSeleccionado))
            {
                richTextBox1.Text = "Seleccione un boleto para ver la información del equipaje.";
                return;
            }

            var boletoSeleccionado = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos()
                .FirstOrDefault(b => b.IdRegistro == idBoletoSeleccionado);

            if (boletoSeleccionado == null)
            {
                richTextBox1.Text = "No se encontró información del boleto seleccionado.";
                return;
            }

            if (boletoSeleccionado.PesoEquipaje > 0 && boletoSeleccionado.CantidadEquipaje > 0)
            {
                richTextBox1.Text = $"--- Información del Equipaje ---\n" +
                                    $"ID Equipaje: {boletoSeleccionado.IdEquipaje ?? "N/A"}\n" +
                                    $"Peso Equipaje: {boletoSeleccionado.PesoEquipaje} kg\n" +
                                    $"Cantidad Equipaje: {boletoSeleccionado.CantidadEquipaje} maleta(s)";
            }
            else
            {
                richTextBox1.Text = "El boleto seleccionado no tiene información de equipaje registrada.";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string idBoletoSeleccionado = comboBox1.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(idBoletoSeleccionado))
            {
                MessageBox.Show("Seleccione un boleto antes de guardar el equipaje.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var boletoSeleccionado = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos()
                .FirstOrDefault(b => b.IdRegistro == idBoletoSeleccionado);

            if (boletoSeleccionado == null)
            {
                MessageBox.Show("Boleto no encontrado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (boletoSeleccionado.PesoEquipaje <= 0 || boletoSeleccionado.CantidadEquipaje <= 0)
            {
                MessageBox.Show("El boleto seleccionado no tiene información válida de equipaje para guardar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var equipaje = new Equipaje(boletoSeleccionado.IdEquipaje, boletoSeleccionado, boletoSeleccionado.PesoEquipaje, boletoSeleccionado.CantidadEquipaje);
            DatosGlobales.ListaGlobalDeEquipajes.AgregarEquipaje(equipaje);
            GuardarEquipajesEnArchivo();

            MessageBox.Show("La información del equipaje ha sido guardada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void GuardarEquipajesEnArchivo()
        {
            List<Equipaje> equipajesAGuardar = DatosGlobales.ListaGlobalDeEquipajes.ObtenerTodosEquipajes();
            Equipaje.GuardarDatos(rutaArchivoEquipajes, equipajesAGuardar);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main_Usuario_Form2 formMainUsuario = new Main_Usuario_Form2();
            formMainUsuario.Show();
            this.Close();
        }

        private void InformacionEquipaje_Form10_FormClosing(object sender, FormClosingEventArgs e)
        {
            GuardarEquipajesEnArchivo();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void InformacionBoleto_Click(object sender, EventArgs e)
        {

        }
    }
}

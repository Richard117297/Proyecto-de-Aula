﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;

namespace Interfaz_Usuario
{
    public partial class InformaciónBoleto_Form3 : Form
    {
        private List<Boleto> boletosCargados; 
        private string rutaArchivoBoletos = @"Base de datos JSON\Boleto.json";


        public InformaciónBoleto_Form3()
        {
            InitializeComponent();
            boletosCargados = new List<Boleto>();
        }

        private void InformaciónBoleto_Form3_Load(object sender, EventArgs e)
        {
            LimpiarCampos(); 
            DeshabilitarControlesIniciales(); 
            CargarBoletosUsuarioEnDesplegable(); 
        }

        private void LimpiarCampos()
        {
            comboBox1.Items.Clear(); 
            comboBox1.SelectedIndex = -1;
            richTextBox1.Clear();
            boletosCargados.Clear();
            DeshabilitarBotonesAccion();
        }

        private void DeshabilitarControlesIniciales()
        {
            button1.Enabled = false; 
            button3.Enabled = false; 
            richTextBox1.Enabled = false; 
        }

        private void DeshabilitarBotonesAccion()
        {
            button1.Enabled = false; 
            button3.Enabled = false; 
        }


        private void CargarBoletosUsuarioEnDesplegable()
        {
            comboBox1.Items.Clear(); 
            boletosCargados.Clear(); 

            if (DatosGlobales.ListaGlobalDeBoletos == null || DatosGlobales.ListaGlobalDeBoletos.Cabeza == null)
            {
                MessageBox.Show("No hay boletos registrados en el sistema.", "Sin Boletos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox1.Enabled = false;
                DeshabilitarBotonesAccion();
                return;
            }


            List<Boleto> todosBoletosDisponibles = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();

            if (todosBoletosDisponibles != null && todosBoletosDisponibles.Count > 0)
            {

                boletosCargados = todosBoletosDisponibles;

                foreach (Boleto boleto in boletosCargados)
                {
                    if (!string.IsNullOrEmpty(boleto.IdRegistro))
                    {
                        comboBox1.Items.Add(boleto.IdRegistro);
                    }
                }

                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Se encontraron boletos, pero no tienen un ID de registro válido para mostrar.", "Sin Boletos Válidos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBox1.Enabled = false;
                    DeshabilitarBotonesAccion();
                }
            }
            else
            {
                MessageBox.Show("No hay boletos disponibles en el sistema.", "Sin Boletos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox1.Enabled = false;
                DeshabilitarBotonesAccion();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            richTextBox1.Enabled = false; 
            DeshabilitarBotonesAccion();


            if (comboBox1.SelectedItem != null)
            {
                string idRegistroSeleccionado = comboBox1.SelectedItem.ToString();
                Boleto boletoSeleccionado = boletosCargados.FirstOrDefault(b => b.IdRegistro != null && b.IdRegistro.Equals(idRegistroSeleccionado, StringComparison.OrdinalIgnoreCase));

                if (boletoSeleccionado != null)
                {
                    richTextBox1.Text = boletoSeleccionado.GetInfoCompleta();
                    richTextBox1.Enabled = true; 

                    button1.Enabled = true; 
                    button3.Enabled = true; 
                }
                else
                {
                    richTextBox1.Text = "No se encontró la información del boleto seleccionado.";
                    richTextBox1.Enabled = false;
                    DeshabilitarBotonesAccion();
                }
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un boleto de la lista.", "Seleccionar Boleto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                richTextBox1.Clear();
                richTextBox1.Enabled = false;
                DeshabilitarBotonesAccion();
                return;
            }

            string idRegistroSeleccionado = comboBox1.SelectedItem.ToString();
            Boleto boletoEncontrado = boletosCargados.FirstOrDefault(b => b.IdRegistro != null && b.IdRegistro.Equals(idRegistroSeleccionado, StringComparison.OrdinalIgnoreCase));

            if (boletoEncontrado != null)
            {
                richTextBox1.Text = boletoEncontrado.GetInfoCompleta();
                richTextBox1.Enabled = true;
            }
            else
            {
                richTextBox1.Text = "No se encontró la información del boleto seleccionado.";
                richTextBox1.Enabled = false;
                DeshabilitarBotonesAccion(); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main_Usuario_Form2 formAnterior = new Main_Usuario_Form2();
            formAnterior.Show();
            this.Close(); 
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un boleto de la lista para eliminar.", "Seleccionar Boleto", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string idRegistroSeleccionado = comboBox1.SelectedItem.ToString();
            DialogResult resultado = MessageBox.Show($"¿Está seguro de que desea eliminar el boleto con ID: {idRegistroSeleccionado}?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    if (DatosGlobales.ListaGlobalDeBoletos != null)
                    {
                        DatosGlobales.ListaGlobalDeBoletos.EliminarBoleto(idRegistroSeleccionado);

                        List<Boleto> listaActualizada = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();
                        Boleto.GuardarDatos(rutaArchivoBoletos, listaActualizada);

                        MessageBox.Show($"El boleto con ID: {idRegistroSeleccionado} ha sido eliminado del sistema.", "Eliminación Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        CargarBoletosUsuarioEnDesplegable();
                        LimpiarCampos(); 


                    }
                    else
                    {
                        MessageBox.Show("Error interno: La lista global de boletos no está disponible para eliminar.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ocurrió un error al intentar eliminar el boleto: {ex.Message}", "Error de Eliminación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Iniciar_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void richTextBox1_TextChanged(object sender, EventArgs e) { }
    }
}

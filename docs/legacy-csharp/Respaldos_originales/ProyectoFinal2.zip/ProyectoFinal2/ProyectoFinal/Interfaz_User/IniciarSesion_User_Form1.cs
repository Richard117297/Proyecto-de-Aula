﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Interfaz_Usuario
{
    public partial class IniciarSesion_User_Form1 : Form
    {
        private Pasajero pasajero;

        public IniciarSesion_User_Form1()
        {
            InitializeComponent();
            pasajero = new Pasajero("david", "ricardo", "98765", 1234567890, "richard", "madrid15", "cedula");
        }

        private void Iniciar_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Ingresar_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string usuario = textBox1.Text; 
            string contrasena = textBox2.Text; 

            bool inicioSesionExitoso = pasajero.IniciarSesion(usuario, contrasena);

            if (inicioSesionExitoso)
            {
                Main_Usuario_Form2 mainUsuarioForm = new Main_Usuario_Form2();
                mainUsuarioForm.Show();
                this.Hide(); 
            }
            else
            {
                MessageBox.Show("Inicio de sesión fallido. Usuario o contraseña incorrectos.", "Error de inicio de sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                textBox1.Text = "";
                textBox2.Text = "";
                textBox1.Focus(); 
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 formInicio = new Form1();
            formInicio.Show();
            this.Close();
        }

        private void IniciarSesion_User_Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

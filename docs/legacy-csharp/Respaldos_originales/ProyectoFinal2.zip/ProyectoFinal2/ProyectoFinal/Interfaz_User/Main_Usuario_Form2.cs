﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;
using ProyectoFinal.Interfaz_User;

namespace Interfaz_Usuario
{
    public partial class Main_Usuario_Form2 : Form
    {
        private string rutaArchivo = @"Base de datos JSON\Boleto.json";
        public Main_Usuario_Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            CompraBoleta_Form4 formCompraBoleto = new CompraBoleta_Form4();
            formCompraBoleto.Show();
            this.Hide();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Cambiar_Ruta_Form7 formCambiarRuta = new Cambiar_Ruta_Form7();
            formCambiarRuta.Show();
            this.Hide();
        }


        private void button3_Click(object sender, EventArgs e)
        {
            InformaciónBoleto_Form3 formInfoBoleto = new InformaciónBoleto_Form3();
            formInfoBoleto.Show();
            this.Hide();
        }




        private void button6_Click(object sender, EventArgs e)
        {
            Form1 formInicio = new Form1(); 
            formInicio.Show();             
            this.Close();
        }

        private void Main_Usuario_Form2_Load(object sender, EventArgs e)
        {
            List<Boleto> boletosCargados = Boleto.CargarDatos(rutaArchivo);

            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {
                foreach (var boleto in boletosCargados)
                {

                    if (!DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos().Any(b => b.IdRegistro == boleto.IdRegistro))
                    {
                        DatosGlobales.ListaGlobalDeBoletos.AddBoleto(boleto);
                    }
                }
            }

            MessageBox.Show("Datos de boletos cargados correctamente.", "Carga Exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Main_Usuario_Form2_FormClosing(object sender, FormClosingEventArgs e)
        {

            List<Boleto> boletosAGuardar = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();
            Boleto.GuardarDatos(rutaArchivo, boletosAGuardar);

            MessageBox.Show("Datos de boletos guardados correctamente.", "Guardado Exitoso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void button4_Click(object sender, EventArgs e)
        {
            InformacionEquipaje_Form10 formEquipaje = new InformacionEquipaje_Form10();
            formEquipaje.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;

namespace Interfaz_Usuario
{
    public partial class Modulo_RutaForm8 : Form
    {
        private Boleto boletoParaCambiar;

        public Modulo_RutaForm8()
        {
            InitializeComponent();
            this.boletoParaCambiar = null;
            DeshabilitarControles();
        }

        public Modulo_RutaForm8(Boleto boleto)
        {
            InitializeComponent();
            this.boletoParaCambiar = boleto;
            MostrarIDBoletoYEstadoInicial();
        }

        private void Modulo_RutaForm8_Load(object sender, EventArgs e)
        {
           
        }

        private void MostrarIDBoletoYEstadoInicial()
        {
            if (this.boletoParaCambiar != null)
            {
 
                textBox4.Text = this.boletoParaCambiar.IdRegistro; 
                DeshabilitarControles();
                button3.Enabled = true;
            }
            else
            {
                textBox4.Text = "N/A"; 
                DeshabilitarControles();
            }
        }

        private void DeshabilitarControles()
        {
 
            textBox1.Clear(); 
            textBox1.Enabled = false;
            textBox2.Clear(); 
            textBox2.Enabled = false;

            button3.Enabled = false; 
            button4.Enabled = false; 

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.boletoParaCambiar != null)
            {

                textBox1.Enabled = true; 
                textBox1.Text = $"{this.boletoParaCambiar.EstacionOrigen} a {this.boletoParaCambiar.EstacionFinal}";

                textBox2.Enabled = true; 
                textBox2.Text = this.boletoParaCambiar.ValorPasaje.ToString(); 

                HabilitarControlesCambioRuta();
            }
            else
            {
                MessageBox.Show("No se ha cargado ningún boleto para mostrar la ruta.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DeshabilitarControles();
            }
        }

        private void HabilitarControlesCambioRuta()
        {

            button4.Enabled = true; 

        }

        private void button4_Click(object sender, EventArgs e)
        {

            Rutas_Recomendada_Form9 formRecomendada = new Rutas_Recomendada_Form9(this.boletoParaCambiar);
            formRecomendada.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Cambiar_Ruta_Form7 formCambiarRuta = new Cambiar_Ruta_Form7(); 
            formCambiarRuta.Show();
            this.Close(); 
        }


        private void textBox4_TextChanged(object sender, EventArgs e) { } 
        private void label8_Click(object sender, EventArgs e) { } 
        private void textBox2_TextChanged(object sender, EventArgs e) { } 
        private void label7_Click(object sender, EventArgs e) { } 
        private void textBox7_TextChanged(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { } 
        private void label3_Click(object sender, EventArgs e) { } 
        private void label2_Click(object sender, EventArgs e) { } 
        private void label1_Click(object sender, EventArgs e) { } 
        private void label4_Click_1(object sender, EventArgs e) { } 
        private void label5_Click_1(object sender, EventArgs e) { } 
        private void textBox2_TextChanged_1(object sender, EventArgs e) { }
    }
}

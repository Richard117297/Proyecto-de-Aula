﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using ProyectoFinal;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Interfaz_Usuario
{
    public partial class Rutas_Recomendada_Form9 : Form
    {
        private Boleto boletoOriginal;
        private Ruta rutaRecomendadaSeleccionadaObjeto;

        private string rutaArchivoBoletos = @"Base de datos JSON\Boleto.json";


        public Rutas_Recomendada_Form9()
        {
            InitializeComponent();
            this.boletoOriginal = null;
            InicializarFormulario();
        }

        public Rutas_Recomendada_Form9(Boleto boleto)
        {
            InitializeComponent();
            this.boletoOriginal = boleto;
            InicializarFormulario(); 
            MostrarInformacionBoletoOriginal(); 
        }

        private void Rutas_Recomendada_Form9_Load(object sender, EventArgs e)
        {

        }

        private void InicializarFormulario()
        {
            CargarEstacionesEnDesplegables(); 

            DeshabilitarControlesSeleccionRuta();
            DeshabilitarBotonCambiarRuta();


            comboBox1.Enabled = (comboBox1.Items.Count > 0); 
            comboBox3.Enabled = (comboBox3.Items.Count > 0); 


            textBox1.Enabled = false; 
            textBox2.Enabled = false; 


            if (this.boletoOriginal == null)
            {
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void CargarEstacionesEnDesplegables()
        {
            comboBox1.Items.Clear(); 
            comboBox3.Items.Clear(); 
            comboBox1.SelectedIndex = -1;
            comboBox3.SelectedIndex = -1;


            if (DatosGlobales.ListaGlobalDeBoletos != null && DatosGlobales.ListaGlobalDeBoletos.Valor != null && DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones != null)
            {

                foreach (var nodoEstacionGrafo in DatosGlobales.ListaGlobalDeBoletos.Valor.Estaciones)
                {

                    if (nodoEstacionGrafo != null && nodoEstacionGrafo.Estacion != null && nodoEstacionGrafo.Estacion.NombreEstacion != null && nodoEstacionGrafo.Estacion.NombreEstacion.Length > 0)
                    {
                        string nombreEstacion = nodoEstacionGrafo.Estacion.NombreEstacion[0];

                        comboBox1.Items.Add(nombreEstacion); 
                        comboBox3.Items.Add(nombreEstacion); 
                    }
                }


                comboBox1.Enabled = (comboBox1.Items.Count > 0);
                comboBox3.Enabled = (comboBox3.Items.Count > 0);

            }
            else
            {
                MessageBox.Show("Error interno: Datos globales o grafo de estaciones no disponibles para cargar estaciones.", "Error de Carga", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox1.Enabled = false;
                comboBox3.Enabled = false;
            }
        }


        private void MostrarInformacionBoletoOriginal()
        {

            if (this.boletoOriginal != null)
            {

                textBox1.Text = $"Original: {this.boletoOriginal.EstacionOrigen} a {this.boletoOriginal.EstacionFinal}";
                textBox2.Text = this.boletoOriginal.ValorPasaje.ToString("C2"); 
            }
            else
            {
                textBox1.Text = "Original: N/A";
                textBox2.Text = "Precio: N/A";

            }
        }


        private void DeshabilitarControlesSeleccionRuta()
        {
            comboBox2.Items.Clear(); 
            comboBox2.Enabled = false;
            comboBox2.SelectedIndex = -1;
            DeshabilitarBotonCambiarRuta();
            rutaRecomendadaSeleccionadaObjeto = null; 
        }


        private void HabilitarControlesSeleccionRuta()
        {
            comboBox2.Enabled = true;
        }

        private void DeshabilitarBotonCambiarRuta()
        {
            button4.Enabled = false; 
        }

        private void HabilitarBotonCambiarRuta()
        {
            button4.Enabled = true; 
        }



        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            DeshabilitarControlesSeleccionRuta(); 

            if (comboBox1.SelectedItem != null && comboBox3.SelectedItem != null)
            {
                FiltrarYMoverRutasRecomendadas();
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

            DeshabilitarControlesSeleccionRuta(); 


            if (comboBox1.SelectedItem != null && comboBox3.SelectedItem != null)
            {
                FiltrarYMoverRutasRecomendadas();
            }
        }

        private void FiltrarYMoverRutasRecomendadas()
        {
            string nombreEstacionOrigen = comboBox1.SelectedItem?.ToString();
            string nombreEstacionLlegada = comboBox3.SelectedItem?.ToString();


            if (string.IsNullOrEmpty(nombreEstacionOrigen) || string.IsNullOrEmpty(nombreEstacionLlegada) || nombreEstacionOrigen == nombreEstacionLlegada)
            {

                DeshabilitarControlesSeleccionRuta();
                if (nombreEstacionOrigen == nombreEstacionLlegada && !string.IsNullOrEmpty(nombreEstacionOrigen))
                {
                    MessageBox.Show("La estación de partida y la estación de llegada deben ser diferentes.", "Selección Inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                return;
            }


 
            if (DatosGlobales.ListaGlobalDeRutasRecomendadas == null)
            {
                MessageBox.Show("Error interno: La lista global de rutas recomendadas no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DeshabilitarControlesSeleccionRuta();
                return;
            }

            List<Ruta> todasRutasRecomendadas = DatosGlobales.ListaGlobalDeRutasRecomendadas.GetAllRutas();



            List<Ruta> rutasCoincidentes = new List<Ruta>();
            if (todasRutasRecomendadas != null)
            {

                rutasCoincidentes = todasRutasRecomendadas
                    .Where(r => r != null &&
                                r.EstacionDePartida != null && r.EstacionDePartida.NombreEstacion != null && r.EstacionDePartida.NombreEstacion.Length > 0 &&
                                r.EstacionDeLlegada != null && r.EstacionDeLlegada.NombreEstacion != null && r.EstacionDeLlegada.NombreEstacion.Length > 0 &&
                                r.EstacionDePartida.NombreEstacion[0].Equals(nombreEstacionOrigen, StringComparison.OrdinalIgnoreCase) &&
                                r.EstacionDeLlegada.NombreEstacion[0].Equals(nombreEstacionLlegada, StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }

            comboBox2.Items.Clear(); 
            comboBox2.SelectedIndex = -1; 
            rutaRecomendadaSeleccionadaObjeto = null; 


            if (rutasCoincidentes.Count > 0)
            {

                foreach (Ruta rutaRec in rutasCoincidentes)
                {

                    if (rutaRec.EstacionDePartida != null && rutaRec.EstacionDePartida.NombreEstacion != null && rutaRec.EstacionDePartida.NombreEstacion.Length > 0 &&
                        rutaRec.EstacionDeLlegada != null && rutaRec.EstacionDeLlegada.NombreEstacion != null && rutaRec.EstacionDeLlegada.NombreEstacion.Length > 0)
                    {
                        comboBox2.Items.Add($"{rutaRec.EstacionDePartida.NombreEstacion[0]} a {rutaRec.EstacionDeLlegada.NombreEstacion[0]} (ID: {rutaRec.IdRuta})");
                    }
                }
                HabilitarControlesSeleccionRuta(); 
                if (comboBox2.Items.Count > 0)
                {
                    comboBox2.SelectedIndex = 0; 
                }
            }
            else
            {

                MessageBox.Show($"No se encontraron rutas recomendadas del administrador directas de {nombreEstacionOrigen} a {nombreEstacionLlegada}.", "Sin Rutas Recomendadas", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DeshabilitarControlesSeleccionRuta();
            }
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            DeshabilitarBotonCambiarRuta(); 
            rutaRecomendadaSeleccionadaObjeto = null;

            string rutaRecomendadaSeleccionadaTexto = comboBox2.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(rutaRecomendadaSeleccionadaTexto))
            {

                if (DatosGlobales.ListaGlobalDeRutasRecomendadas != null)
                {
                    List<Ruta> todasRutasRecomendadas = DatosGlobales.ListaGlobalDeRutasRecomendadas.GetAllRutas();

                    rutaRecomendadaSeleccionadaObjeto = todasRutasRecomendadas?
                        .FirstOrDefault(r => r != null && r.EstacionDePartida != null && r.EstacionDeLlegada != null && r.IdRuta != null &&
                                              $"{r.EstacionDePartida.NombreEstacion[0]} a {r.EstacionDeLlegada.NombreEstacion[0]} (ID: {r.IdRuta})" == rutaRecomendadaSeleccionadaTexto);


                    if (rutaRecomendadaSeleccionadaObjeto != null)
                    {
                        HabilitarBotonCambiarRuta();
                    }
                    else
                    {
                        MessageBox.Show("Error interno: No se pudo encontrar el objeto Ruta seleccionado en la lista global.", "Error de Sincronización", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {

                    MessageBox.Show("Error interno: La lista global de rutas recomendadas no está disponible.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }



        private void button4_Click(object sender, EventArgs e)
        {

            if (this.boletoOriginal == null)
            {
                MessageBox.Show("No hay un boleto cargado para cambiar la ruta.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (rutaRecomendadaSeleccionadaObjeto == null)
            {
                MessageBox.Show("Seleccione una ruta recomendada primero.", "Selección Pendiente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            this.boletoOriginal.EstacionOrigen = rutaRecomendadaSeleccionadaObjeto.EstacionDePartida?.NombreEstacion[0];
            this.boletoOriginal.EstacionFinal = rutaRecomendadaSeleccionadaObjeto.EstacionDeLlegada?.NombreEstacion[0];

            try
            {

                if (DatosGlobales.ListaGlobalDeBoletos != null)
                {
                    List<Boleto> todosLosBoletos = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos();
                    Boleto.GuardarDatos(rutaArchivoBoletos, todosLosBoletos);
                    MessageBox.Show($"Ruta del boleto {this.boletoOriginal.IdRegistro} actualizada exitosamente a {this.boletoOriginal.EstacionOrigen} a {this.boletoOriginal.EstacionFinal} y los cambios guardados.", "Boleto Actualizado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Modulo_RutaForm8 volveralForm8 = new Modulo_RutaForm8(this.boletoOriginal); 
                    volveralForm8.Show();
                    this.Close(); 

                }
                else
                {
                    MessageBox.Show("Error interno: La lista global de boletos no está disponible para guardar el cambio.", "Error del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error al guardar los datos después de cambiar la ruta del boleto: {ex.Message}", "Error al Guardar", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void button2_Click(object sender, EventArgs e)
        {
            Modulo_RutaForm8 volveralForm8 = new Modulo_RutaForm8(this.boletoOriginal);
            volveralForm8.Show();
            this.Close(); 
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }

        private void label8_Click(object sender, EventArgs e) { }


        private void textBox1_TextChanged(object sender, EventArgs e) { } 
        private void textBox2_TextChanged(object sender, EventArgs e) { }
                                                                          
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }

        private void textBox4_TextChanged(object sender, EventArgs e) { }

        private void label7_Click_1(object sender, EventArgs e)
        {

        }
    }
}

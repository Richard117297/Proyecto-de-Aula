﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Codigo_ProyectoAula;
using Interfaz_Usuario;

namespace ProyectoFinal.Interfaz_User
{
    public partial class Seleccion_Asiento_Form5_5 : Form
    {
        private Boleto boletoActual;
        private Button asientoSeleccionadoButtonTemporal;

        public Seleccion_Asiento_Form5_5(Boleto boleto)
        {
            InitializeComponent();
            this.boletoActual = boleto;
            this.asientoSeleccionadoButtonTemporal = null;
            MostrarInformacionBoleto();
        }

        public Seleccion_Asiento_Form5_5()
        {
            InitializeComponent();
            this.boletoActual = null;
            MessageBox.Show("Este formulario no debe abrirse directamente sin la información del boleto.", "Error de Navegación", MessageBoxButtons.OK, MessageBoxIcon.Error);
            DeshabilitarControlesSeleccionAsiento();
            button36.Enabled = false;
        }

        private void Seleccion_Asiento_Form5_5_Load(object sender, EventArgs e)
        {
            if (this.boletoActual != null)
            {
                CargarVagonesDisponibles();
                DeshabilitarBotonesAsiento();
                button36.Enabled = false;
            }
            else
            {
                DeshabilitarControlesSeleccionAsiento();
                button36.Enabled = false;
            }
        }

        private void MostrarInformacionBoleto()
        {
            if (this.boletoActual != null)
            {
                textBox1.Text = $"{boletoActual.EstacionOrigen} a {boletoActual.EstacionFinal}";
                textBox2.Text = boletoActual.IdTren;
                textBox3.Text = boletoActual.FechaHoraSalida;
                textBox4.Text = boletoActual.TipoDeBoleta.ToString();

                textBox6.Clear();
                textBox5.Clear();
            }
        }

        private void DeshabilitarControlesSeleccionAsiento()
        {
            comboBox4.Enabled = false;
            textBox5.Enabled = false;
            DeshabilitarBotonesAsiento();
            button36.Enabled = false;
        }

        private void DeshabilitarBotonesAsiento()
        {
            foreach (Control control in flowLayoutPanel1.Controls)
            {
                if (control is Button asientoButton)
                {
                    asientoButton.Enabled = false;
                }
            }
        }

        private void CargarVagonesDisponibles()
        {
            comboBox4.Items.Clear();
            comboBox4.SelectedIndex = -1;
            textBox5.Clear();

            if (this.boletoActual == null || string.IsNullOrEmpty(this.boletoActual.IdTren))
            {
                comboBox4.Enabled = false;
                return;
            }

            Tren trenAsignado = DatosGlobales.ListaGlobalDeTrenes.BuscarTrenPorId(this.boletoActual.IdTren);

            if (trenAsignado == null || trenAsignado.PilaVagones == null)
            {
                MessageBox.Show($"No se encontraron vagones para el tren '{this.boletoActual.IdTren}'.", "Error de Vagones", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                comboBox4.Enabled = false;
                return;
            }

            List<Vagon> todosLosVagonesDelTren = trenAsignado.PilaVagones.GetAllVagones();

            List<Vagon> vagonesDisponiblesParaTipoBoleto = todosLosVagonesDelTren
                 .Where(v => v.TipoBoleto == this.boletoActual.TipoDeBoleta)
                 .ToList();


            if (vagonesDisponiblesParaTipoBoleto.Count > 0)
            {
                foreach (Vagon vagon in vagonesDisponiblesParaTipoBoleto)
                {
                    comboBox4.Items.Add(vagon.IdDelVagon);
                }
                comboBox4.Enabled = true;
            }
            else
            {
                MessageBox.Show($"No se encontraron vagones de tipo '{this.boletoActual.TipoDeBoleta}' para el tren '{this.boletoActual.IdTren}'. Asegúrese de que se han agregado vagones de este tipo al tren.", "Sin Vagones Disponibles", MessageBoxButtons.OK, MessageBoxIcon.Information);
                comboBox4.Enabled = false;
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            string idVagonSeleccionado = comboBox4.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(idVagonSeleccionado))
            {
                textBox5.Text = idVagonSeleccionado;
                CargarVisualizacionAsientos(idVagonSeleccionado);
                button36.Enabled = false;
                textBox6.Clear();
                asientoSeleccionadoButtonTemporal = null;
            }
            else
            {
                textBox5.Clear();
                DeshabilitarBotonesAsiento();
                button36.Enabled = false;
                textBox6.Clear();
                asientoSeleccionadoButtonTemporal = null;
            }
        }

        private void CargarVisualizacionAsientos(string idVagon)
        {
            foreach (Control control in flowLayoutPanel1.Controls)
            {
                if (control is Button asientoButton)
                {
                    asientoButton.BackColor = SystemColors.Control;
                    asientoButton.Enabled = true;
                }
            }

            Tren trenAsignado = DatosGlobales.ListaGlobalDeTrenes.BuscarTrenPorId(this.boletoActual.IdTren);
            Vagon vagonSeleccionado = trenAsignado?.PilaVagones.BuscarVagonPorId(idVagon);

            if (vagonSeleccionado == null)
            {
                DeshabilitarBotonesAsiento();
                return;
            }

            int capacidadAsientosVagon = vagonSeleccionado.GetCapacidadPorTipoBoleto();

            foreach (Control control in flowLayoutPanel1.Controls)
            {
                if (control is Button asientoButton && int.TryParse(asientoButton.Text, out int numeroAsiento))
                {
                    if (numeroAsiento > capacidadAsientosVagon)
                    {
                        asientoButton.Enabled = false;
                        asientoButton.BackColor = Color.LightGray;
                    }
                }
            }

            if (DatosGlobales.ListaGlobalDeBoletos != null)
            {
                foreach (Boleto boleto in DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos())
                {
                    if (boleto.IdTren == this.boletoActual.IdTren &&
                        boleto.FechaHoraSalida == this.boletoActual.FechaHoraSalida &&
                        boleto.IdVagonCarga == idVagon &&
                        boleto.NumeroAsiento > 0)
                    {
                        string numeroAsientoOcupado = boleto.NumeroAsiento.ToString();
                        Button asientoOcupadoButton = flowLayoutPanel1.Controls.OfType<Button>()
                                                         .FirstOrDefault(btn => btn.Text == numeroAsientoOcupado);

                        if (asientoOcupadoButton != null)
                        {
                            asientoOcupadoButton.BackColor = Color.Red;
                            asientoOcupadoButton.Enabled = false;
                        }
                    }
                }
            }

            foreach (Control control in flowLayoutPanel1.Controls)
            {
                if (control is Button asientoButton)
                {
                    if (asientoButton.BackColor != Color.Red && asientoButton.Enabled)
                    {
                        asientoButton.Enabled = true;
                    }
                    else if (asientoButton.BackColor != Color.Red && !asientoButton.Enabled)
                    {
                        asientoButton.BackColor = SystemColors.Control;
                    }
                }
            }
        }

        private void AsientoButton_Click(object sender, EventArgs e)
        {
            Button botonAsiento = sender as Button;
            if (botonAsiento != null && botonAsiento.Enabled && botonAsiento.BackColor != Color.Red)
            {
                if (asientoSeleccionadoButtonTemporal != null)
                {
                    asientoSeleccionadoButtonTemporal.BackColor = SystemColors.Control;
                }

                botonAsiento.BackColor = Color.Yellow;
                asientoSeleccionadoButtonTemporal = botonAsiento;

                textBox6.Text = botonAsiento.Text;

                button36.Enabled = true;
            }
        }

        private void button36_Click(object sender, EventArgs e)
        {
            if (asientoSeleccionadoButtonTemporal == null || string.IsNullOrEmpty(textBox6.Text))
            {
                MessageBox.Show("Por favor, seleccione un asiento antes de confirmar.", "Selección Pendiente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (this.boletoActual == null)
            {
                MessageBox.Show("Error interno: No hay información de boleto para confirmar asiento.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int numeroAsientoConfirmado;
            if (!int.TryParse(textBox6.Text, out numeroAsientoConfirmado))
            {
                MessageBox.Show("Error al obtener el número de asiento seleccionado.", "Error de Asiento", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string idVagonSeleccionado = textBox5.Text;
            if (string.IsNullOrEmpty(idVagonSeleccionado))
            {
                MessageBox.Show("Error interno: No se ha seleccionado un vagón.", "Error de Vagón", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool asientoYaOcupadoPorOtro = DatosGlobales.ListaGlobalDeBoletos.GetAllBoletos()
                .Any(b => b.IdTren == this.boletoActual.IdTren &&
                          b.FechaHoraSalida == this.boletoActual.FechaHoraSalida &&
                          b.IdVagonCarga == idVagonSeleccionado &&
                          b.NumeroAsiento > 0);

            if (asientoYaOcupadoPorOtro)
            {
                MessageBox.Show($"El asiento {numeroAsientoConfirmado} en el vagón {idVagonSeleccionado} acaba de ser ocupado por otro usuario. Por favor, seleccione otro asiento.", "Asiento Ocupado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                CargarVisualizacionAsientos(idVagonSeleccionado);
                textBox6.Clear();
                if (asientoSeleccionadoButtonTemporal != null)
                {
                    asientoSeleccionadoButtonTemporal.BackColor = SystemColors.Control;
                }
                asientoSeleccionadoButtonTemporal = null;
                button36.Enabled = false;
                return;
            }

            this.boletoActual.NumeroAsiento = numeroAsientoConfirmado;
            this.boletoActual.IdVagonCarga = idVagonSeleccionado;

            asientoSeleccionadoButtonTemporal.BackColor = Color.Red;
            asientoSeleccionadoButtonTemporal.Enabled = false;

            MessageBox.Show($"Asiento {numeroAsientoConfirmado} en vagón {this.boletoActual.IdVagonCarga} confirmado.", "Asiento Confirmado", MessageBoxButtons.OK, MessageBoxIcon.Information);

            ComfimarCompra_Form6 formConfirmacion = new ComfimarCompra_Form6(this.boletoActual);
            formConfirmacion.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DigitarInfo_Boleto_Form5 formAnterior = new DigitarInfo_Boleto_Form5();
            formAnterior.Show();
            this.Close();
        }

        private void buttonActualizar_Click(object sender, EventArgs e)
        {
            CargarVagonesDisponibles();
            MessageBox.Show("Lista de vagones actualizada.", "Actualización Completa", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button1_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button3_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button5_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button4_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button6_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button7_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button8_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button9_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button10_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button11_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button12_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button13_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button14_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button15_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button16_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button17_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button18_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button19_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button20_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button21_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button22_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button23_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button24_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button25_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button26_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button27_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button28_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button29_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button30_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button31_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button32_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button33_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button34_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }
        private void button35_Click(object sender, EventArgs e) { AsientoButton_Click(sender, e); }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void label13_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Seleccion_Asiento_Form5_5_Load_1(object sender, EventArgs e)
        {

        }
    }
}
